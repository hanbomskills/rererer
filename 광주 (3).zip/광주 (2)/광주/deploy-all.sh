#!/usr/bin/env bash
# =============================================================================
# Skills Competition 2025 - Bastion Auto Deploy (100% 기준 충족형)
# - CloudFormation 네이밍 및 채점 스펙을 엄격히 준수
# - 재실행/부분실패 안전(idempotent)
# - 필수 리소스 자동 생성/보완
# =============================================================================
set -euo pipefail
IFS=$'\n\t'

# ---------- 색상 & 로깅 ----------
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; PURPLE='\033[0;35m'; NC='\033[0m'
info(){ echo -e "${BLUE}ℹ️  $*${NC}"; }
ok(){ echo -e "${GREEN}✅ $*${NC}"; }
warn(){ echo -e "${YELLOW}⚠️  $*${NC}"; }
err(){ echo -e "${RED}❌ $*${NC}"; }
step(){ echo -e "${PURPLE}🚀 $*${NC}"; }

# ---------- 계정·리전·의존성 보장 ----------
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
AWS_REGION="${AWS_REGION:-ap-northeast-2}"
export AWS_DEFAULT_REGION="$AWS_REGION"
aws configure set default.region "$AWS_REGION" >/dev/null

# 필수 도구 확인 및 설치
if ! command -v eksctl >/dev/null 2>&1; then
  info "eksctl 설치 중..."
  curl -fsSL "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | sudo tar xz -C /usr/local/bin
  chmod +x /usr/local/bin/eksctl
fi

if ! command -v aws >/dev/null 2>&1; then
  err "AWS CLI가 설치되지 않았습니다. AWS CLI를 먼저 설치하세요."
  exit 1
fi

if ! command -v kubectl >/dev/null 2>&1; then
  info "kubectl 설치 중..."
  curl -fsSL -o kubectl "https://dl.k8s.io/release/$(curl -fsSL https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
  chmod +x kubectl && sudo mv kubectl /usr/local/bin/
fi

if ! command -v helm >/dev/null 2>&1; then
  info "helm 설치 중..."
  curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
fi

if ! command -v jq >/dev/null 2>&1; then
  info "jq 설치 중..."
  if command -v dnf >/dev/null 2>&1; then
    sudo dnf -y install jq
  else
    sudo yum -y install jq
  fi
fi

if ! command -v unzip >/dev/null 2>&1; then
  info "unzip 설치 중..."
  if command -v dnf >/dev/null 2>&1; then
    sudo dnf -y install unzip
  else
    sudo yum -y install unzip
  fi
fi

if ! command -v git >/dev/null 2>&1; then
  info "git 설치 중..."
  if command -v dnf >/dev/null 2>&1; then
    sudo dnf -y install git
  else
    sudo yum -y install git
  fi
fi

if ! command -v docker >/dev/null 2>&1; then
  info "docker 설치 중..."
  if command -v dnf >/dev/null 2>&1; then
    sudo dnf -y install docker
  else
    sudo yum -y install docker
  fi
  sudo systemctl enable --now docker
  sudo usermod -a -G docker ec2-user || true
fi

if ! command -v gh >/dev/null 2>&1; then
  info "GitHub CLI 설치 중..."
  GH_V=$(curl -fsSL https://api.github.com/repos/cli/cli/releases/latest | jq -r .tag_name | sed 's/^v//')
  curl -fsSL -o gh.tar.gz "https://github.com/cli/cli/releases/download/v${GH_V}/gh_${GH_V}_linux_amd64.tar.gz"
  tar -xzf gh.tar.gz && sudo mv gh_*_linux_amd64/bin/gh /usr/local/bin/ && rm -rf gh.tar.gz gh_*_linux_amd64
fi

if ! command -v argocd >/dev/null 2>&1; then
  info "ArgoCD CLI 설치 중..."
  curl -fsSL -o argocd-linux-amd64 https://github.com/argoproj/argo-cd/releases/latest/download/argocd-linux-amd64
  chmod +x argocd-linux-amd64 && sudo mv argocd-linux-amd64 /usr/local/bin/argocd
fi

# 도구 버전 확인
aws --version >/dev/null || { err "AWS CLI 버전 확인 실패"; exit 1; }
eksctl version >/dev/null || { err "eksctl 버전 확인 실패"; exit 1; }
kubectl version --client >/dev/null || { err "kubectl 버전 확인 실패"; exit 1; }
helm version >/dev/null || { err "helm 버전 확인 실패"; exit 1; }

# ---------- 파라미터 ----------
if [[ $# -ne 1 ]]; then
  err "사용법: $0 <GitHub_Token>"; exit 1
fi
GITHUB_TOKEN="$1"

# ---------- 고정 이름(채점 기준) ----------
AWS_REGION="ap-northeast-2"
CLUSTER_NAME="gj2025-eks-cluster"
K8S_NAMESPACE="skills"
GITHUB_REPO="gj2025-repository"

# CloudFormation 스택 논리명 (동적 탐지)
CFN_STACK=""
# 가능한 스택 이름들을 시도
for stack_name in "gj2025-stack" "gj2025-infrastructure" "gj2025-competition" "gj2025"; do
  if aws cloudformation describe-stacks --stack-name "$stack_name" >/dev/null 2>&1; then
    CFN_STACK="$stack_name"
    break
  fi
done

if [[ -z "$CFN_STACK" ]]; then
  # 모든 스택을 나열하여 확인
  info "사용 가능한 CloudFormation 스택:"
  aws cloudformation list-stacks --stack-status-filter CREATE_COMPLETE UPDATE_COMPLETE --query 'StackSummaries[].StackName' --output table || true
  err "CloudFormation 스택을 찾을 수 없습니다. 스택 이름을 수동으로 설정하세요."
  exit 1
fi
info "사용할 CloudFormation 스택: $CFN_STACK"
TGW_RTB_HUB="TGWRouteTableHub"
TGW_RTB_APP="TGWRouteTableApp"
TGW_ATTACH_HUB="TGWAttachHub"
TGW_ATTACH_APP="TGWAttachApp"

# 네트워크 & 로드밸런서(채점 이름 고정)
ALB_NAME="gj2025-app-alb"
INTERNAL_NLB_NAME="gj2025-app-internal-nlb"
EXTERNAL_NLB_NAME="gj2025-app-external-nlb"
INTERNAL_TG_NAME="gj2025-app-internal-tg"
EXTERNAL_TG_NAME="gj2025-app-external-tg"

# 서브넷/VPC 태그명(문제/채점 문서 기준)
APP_VPC_TAG="gj2025-app-vpc"
PRIV_SUBNET_A="gj2025-app-private-subnet-a"
PRIV_SUBNET_B="gj2025-app-private-subnet-b"

# 시크릿/IRSA/역할/리포지토리(채점 고정)
CATALOG_SECRET_NAME="gj2025-eks-cluster-catalog-secret"
IRSA_ES_ROLE="SkillsExternalSecretsRole"
ALB_CTRL_ROLE="AmazonEKSLoadBalancerControllerRole"
ARGO_REPO_ROLE="ArgocdRepoServerRole"

# ECR 리포지토리
ECR_GREEN="green"
ECR_RED="red"

# ---------- 환경 (이미 위에서 설정됨) ----------

# ---------- 추가 패키지 설치 ----------
step "추가 패키지 설치"
if command -v dnf >/dev/null 2>&1; then PKG="dnf"; else PKG="yum"; fi
sudo $PKG -y update || true
sudo $PKG -y install mariadb105 || true
ok "추가 패키지 설치 완료"

# ---------- GitHub 인증 ----------
echo "$GITHUB_TOKEN" | gh auth login --with-token
GITHUB_USER="$(gh api user --jq .login)"
ok "GitHub 사용자: $GITHUB_USER"

# ---------- 리소스 자동 탐지 ----------
step "리소스 자동 탐지"
# CloudFormation Outputs에서 정확한 버킷명 조회 (여러 키 시도)
BUCKET_NAME=""
for key in "BucketName" "AppChartBucket" "S3Bucket" "Bucket"; do
  BUCKET_NAME="$(aws cloudformation describe-stacks --stack-name "$CFN_STACK" --query "Stacks[0].Outputs[?OutputKey==\`$key\`].OutputValue" --output text 2>/dev/null || true)"
  if [[ -n "${BUCKET_NAME:-}" && "$BUCKET_NAME" != "None" ]]; then
    break
  fi
done

if [[ -z "${BUCKET_NAME:-}" || "$BUCKET_NAME" == "None" ]]; then 
  err "CloudFormation 스택에서 S3 버킷을 찾을 수 없음. Outputs 키를 확인하세요."; exit 1
fi
ok "S3 버킷 확인: $BUCKET_NAME"

# S3 버킷 버저닝 확인 및 활성화
VERSIONING_STATUS="$(aws s3api get-bucket-versioning --bucket "$BUCKET_NAME" --query 'Status' --output text 2>/dev/null || echo 'None')"
if [[ "$VERSIONING_STATUS" != "Enabled" ]]; then
  aws s3api put-bucket-versioning --bucket "$BUCKET_NAME" --versioning-configuration Status=Enabled >/dev/null 2>&1 || true
  ok "S3 버킷 버저닝 활성화 완료"
else
  ok "S3 버킷 버저닝 이미 활성화됨"
fi

APP_VPC_ID="$(aws ec2 describe-vpcs --filters Name=tag:Name,Values=$APP_VPC_TAG --query 'Vpcs[0].VpcId' --output text)"
if [[ "$APP_VPC_ID" == "None" || -z "$APP_VPC_ID" ]]; then err "VPC($APP_VPC_TAG) 없음"; exit 1; fi

SUBNET_A="$(aws ec2 describe-subnets --filters Name=tag:Name,Values=$PRIV_SUBNET_A --query 'Subnets[0].SubnetId' --output text)"
SUBNET_B="$(aws ec2 describe-subnets --filters Name=tag:Name,Values=$PRIV_SUBNET_B --query 'Subnets[0].SubnetId' --output text)"
if [[ "$SUBNET_A" == "None" || -z "$SUBNET_A" || "$SUBNET_B" == "None" || -z "$SUBNET_B" ]]; then
  err "프라이빗 서브넷 태그($PRIV_SUBNET_A/$PRIV_SUBNET_B) 미발견"; exit 1
fi

# ---------- 선점검 가드 ----------
step "선점검 가드 실행"

# 1) 프라이빗 RT 기본경로 확인
info "프라이빗 라우트테이블 기본경로 확인"
PRIV_RT_A=$(aws ec2 describe-route-tables --filters "Name=tag:Name,Values=gj2025-app-private-rtb-a" --query 'RouteTables[0].RouteTableId' --output text 2>/dev/null || echo "")
PRIV_RT_B=$(aws ec2 describe-route-tables --filters "Name=tag:Name,Values=gj2025-app-private-rtb-b" --query 'RouteTables[0].RouteTableId' --output text 2>/dev/null || echo "")

if [[ -z "$PRIV_RT_A" || -z "$PRIV_RT_B" ]]; then
  err "프라이빗 라우트테이블을 찾을 수 없습니다. CloudFormation 스택을 먼저 배포하세요."
  exit 1
fi

# 기본경로 확인 (0.0.0.0/0)
DEFAULT_ROUTE_A=$(aws ec2 describe-route-tables --route-table-ids "$PRIV_RT_A" --query 'RouteTables[0].Routes[?DestinationCidrBlock==`0.0.0.0/0`]' --output text)
DEFAULT_ROUTE_B=$(aws ec2 describe-route-tables --route-table-ids "$PRIV_RT_B" --query 'RouteTables[0].Routes[?DestinationCidrBlock==`0.0.0.0/0`]' --output text)

if [[ -z "$DEFAULT_ROUTE_A" || -z "$DEFAULT_ROUTE_B" ]]; then
  err "프라이빗 라우트테이블에 0.0.0.0/0 기본경로가 없습니다."
  exit 1
fi
ok "프라이빗 라우트테이블 기본경로 확인 완료"

# 2) 서브넷 태그 3종 확인
info "서브넷 Kubernetes 태그 확인"
K8S_TAG_COUNT=$(aws ec2 describe-subnets --filters Name=vpc-id,Values="$APP_VPC_ID" Name=tag-key,Values="kubernetes.io/cluster/${CLUSTER_NAME}" --query 'length(Subnets)' --output text 2>/dev/null || echo "0")
INTERNAL_ELB_TAG_COUNT=$(aws ec2 describe-subnets --filters Name=vpc-id,Values="$APP_VPC_ID" Name=tag-key,Values="kubernetes.io/role/internal-elb" --query 'length(Subnets)' --output text 2>/dev/null || echo "0")
ELB_TAG_COUNT=$(aws ec2 describe-subnets --filters Name=vpc-id,Values="$APP_VPC_ID" Name=tag-key,Values="kubernetes.io/role/elb" --query 'length(Subnets)' --output text 2>/dev/null || echo "0")

if [[ "$K8S_TAG_COUNT" -lt 2 || "$INTERNAL_ELB_TAG_COUNT" -lt 2 || "$ELB_TAG_COUNT" -lt 2 ]]; then
  err "서브넷에 필요한 Kubernetes 태그가 부족합니다."
  err "K8S 태그: $K8S_TAG_COUNT, Internal ELB: $INTERNAL_ELB_TAG_COUNT, ELB: $ELB_TAG_COUNT"
  exit 1
fi
ok "서브넷 Kubernetes 태그 확인 완료"

# 3) EKS/STS/ECR/S3 DNS 확인 및 누락 엔드포인트 생성
info "필수 엔드포인트 DNS 확인 및 누락 엔드포인트 생성"

# VPC 엔드포인트용 보안그룹 확인/생성
VPCE_SG=$(aws ec2 describe-security-groups --filters "Name=group-name,Values=gj2025-vpce-sg" "Name=vpc-id,Values=$APP_VPC_ID" --query 'SecurityGroups[0].GroupId' --output text 2>/dev/null || echo "")
if [[ -z "$VPCE_SG" || "$VPCE_SG" == "None" ]]; then
  info "VPC 엔드포인트용 보안그룹 생성 중..."
  VPCE_SG=$(aws ec2 create-security-group \
    --group-name gj2025-vpce-sg \
    --description "VPC Endpoint Security Group" \
    --vpc-id "$APP_VPC_ID" \
    --query 'GroupId' --output text 2>/dev/null || echo "")
  
  # 443 인바운드 허용 (노드에서 VPC 엔드포인트로)
  aws ec2 authorize-security-group-ingress \
    --group-id "$VPCE_SG" \
    --protocol tcp --port 443 --cidr 0.0.0.0/0 >/dev/null 2>&1 || true
fi

# 기본 경로 확인 (NAT/IGW 없으면 VPC 엔드포인트 강제 생성)
info "기본 경로 확인 중..."
DEFAULT_ROUTE_TARGET_A=$(aws ec2 describe-route-tables --route-table-ids "$PRIV_RT_A" --query 'RouteTables[0].Routes[?DestinationCidrBlock==`0.0.0.0/0`].GatewayId' --output text 2>/dev/null || echo "None")
DEFAULT_ROUTE_TARGET_B=$(aws ec2 describe-route-tables --route-table-ids "$PRIV_RT_B" --query 'RouteTables[0].Routes[?DestinationCidrBlock==`0.0.0.0/0`].GatewayId' --output text 2>/dev/null || echo "None")

# NAT/IGW가 없으면 VPC 엔드포인트 강제 생성 필요
FORCE_VPCE=false
if [[ "$DEFAULT_ROUTE_TARGET_A" == "None" || "$DEFAULT_ROUTE_TARGET_B" == "None" ]]; then
  FORCE_VPCE=true
  warn "기본 경로에 NAT/IGW가 없습니다. VPC 엔드포인트 강제 생성이 필요합니다."
elif [[ "$DEFAULT_ROUTE_TARGET_A" != *"nat-"* && "$DEFAULT_ROUTE_TARGET_A" != *"igw-"* ]]; then
  FORCE_VPCE=true
  warn "기본 경로가 NAT/IGW가 아닙니다. VPC 엔드포인트 강제 생성이 필요합니다."
fi

# 필수 엔드포인트들 확인 및 생성 (수정된 도메인명 사용)
REQUIRED_ENDPOINTS=(
  "eks:com.amazonaws.${AWS_REGION}.eks:Interface"
  "ec2:com.amazonaws.${AWS_REGION}.ec2:Interface"
  "api.ecr:com.amazonaws.${AWS_REGION}.ecr.api:Interface"
  "dkr.ecr:com.amazonaws.${AWS_REGION}.ecr.dkr:Interface"
  "sts:com.amazonaws.${AWS_REGION}.sts:Interface"
  "logs:com.amazonaws.${AWS_REGION}.logs:Interface"
  "s3:com.amazonaws.${AWS_REGION}.s3:Gateway"
)

for endpoint_info in "${REQUIRED_ENDPOINTS[@]}"; do
  IFS=':' read -r name service_name endpoint_type <<< "$endpoint_info"
  
  # 기존 엔드포인트 확인
  EXISTING_ENDPOINT=$(aws ec2 describe-vpc-endpoints \
    --filters "Name=service-name,Values=$service_name" "Name=vpc-id,Values=$APP_VPC_ID" \
    --query 'VpcEndpoints[0].VpcEndpointId' --output text 2>/dev/null || echo "None")
  
  if [[ "$EXISTING_ENDPOINT" != "None" && -n "$EXISTING_ENDPOINT" ]]; then
    # 기존 엔드포인트 상태 확인
    ENDPOINT_STATE=$(aws ec2 describe-vpc-endpoints --vpc-endpoint-ids "$EXISTING_ENDPOINT" --query 'VpcEndpoints[0].State' --output text 2>/dev/null || echo "Unknown")
    if [[ "$ENDPOINT_STATE" == "available" ]]; then
      ok "$name 엔드포인트 활성화됨 (기존)"
    else
      warn "$name 엔드포인트 상태: $ENDPOINT_STATE"
    fi
  else
    # 새 엔드포인트 생성 (NAT/IGW 없으면 강제 생성)
    if [[ "$FORCE_VPCE" == "true" || "$name" == "eks" || "$name" == "ec2" ]]; then
      info "$name 엔드포인트 생성 중... (강제 생성)"
      if [[ "$endpoint_type" == "Interface" ]]; then
        aws ec2 create-vpc-endpoint \
          --vpc-endpoint-type Interface \
          --vpc-id "$APP_VPC_ID" \
          --service-name "$service_name" \
          --subnet-ids "$SUBNET_A" "$SUBNET_B" \
          --security-group-ids "$VPCE_SG" \
          --private-dns-enabled \
          --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=gj2025-${name}-endpoint}]" >/dev/null 2>&1 || true
      elif [[ "$endpoint_type" == "Gateway" ]]; then
        aws ec2 create-vpc-endpoint \
          --vpc-endpoint-type Gateway \
          --vpc-id "$APP_VPC_ID" \
          --service-name "$service_name" \
          --route-table-ids "$PRIV_RT_A" "$PRIV_RT_B" \
          --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=gj2025-${name}-endpoint}]" >/dev/null 2>&1 || true
      fi
      
      # 생성 후 상태 확인
      sleep 10
      NEW_ENDPOINT=$(aws ec2 describe-vpc-endpoints \
        --filters "Name=service-name,Values=$service_name" "Name=vpc-id,Values=$APP_VPC_ID" \
        --query 'VpcEndpoints[0].State' --output text 2>/dev/null || echo "Unknown")
      if [[ "$NEW_ENDPOINT" == "available" ]]; then
        ok "$name 엔드포인트 생성 완료"
      else
        warn "$name 엔드포인트 생성 상태: $NEW_ENDPOINT"
      fi
    else
      # DNS 확인 후 필요시에만 생성
      if ! getent hosts "${name}.${AWS_REGION}.amazonaws.com" >/dev/null 2>&1; then
        warn "DNS 확인 실패: ${name}.${AWS_REGION}.amazonaws.com - VPC 엔드포인트 생성 중..."
        if [[ "$endpoint_type" == "Interface" ]]; then
          aws ec2 create-vpc-endpoint \
            --vpc-endpoint-type Interface \
            --vpc-id "$APP_VPC_ID" \
            --service-name "$service_name" \
            --subnet-ids "$SUBNET_A" "$SUBNET_B" \
            --security-group-ids "$VPCE_SG" \
            --private-dns-enabled \
            --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=gj2025-${name}-endpoint}]" >/dev/null 2>&1 || true
        elif [[ "$endpoint_type" == "Gateway" ]]; then
          aws ec2 create-vpc-endpoint \
            --vpc-endpoint-type Gateway \
            --vpc-id "$APP_VPC_ID" \
            --service-name "$service_name" \
            --route-table-ids "$PRIV_RT_A" "$PRIV_RT_B" \
            --tag-specifications "ResourceType=vpc-endpoint,Tags=[{Key=Name,Value=gj2025-${name}-endpoint}]" >/dev/null 2>&1 || true
        fi
        
        # 생성 후 상태 확인
        sleep 10
        NEW_ENDPOINT=$(aws ec2 describe-vpc-endpoints \
          --filters "Name=service-name,Values=$service_name" "Name=vpc-id,Values=$APP_VPC_ID" \
          --query 'VpcEndpoints[0].State' --output text 2>/dev/null || echo "Unknown")
        if [[ "$NEW_ENDPOINT" == "available" ]]; then
          ok "$name 엔드포인트 생성 완료"
        else
          warn "$name 엔드포인트 생성 상태: $NEW_ENDPOINT"
        fi
      else
        ok "DNS 확인 성공: ${name}.${AWS_REGION}.amazonaws.com"
      fi
    fi
  fi
done

# EKS 클러스터 엔드포인트 연결성 확인
info "EKS 클러스터 엔드포인트 연결성 확인"
EKS_ENDPOINT="$(aws eks describe-cluster --name "$CLUSTER_NAME" --query 'cluster.endpoint' --output text 2>/dev/null || echo '')"
if [[ -n "$EKS_ENDPOINT" ]]; then
  EKS_HOST=$(echo "$EKS_ENDPOINT" | sed 's|https://||')
  if timeout 5 bash -lc "cat </dev/null >/dev/tcp/$EKS_HOST/443" 2>/dev/null; then
    ok "EKS API 엔드포인트 연결 성공"
  else
    warn "EKS API 엔드포인트 연결 실패: $EKS_HOST:443"
  fi
fi

ok "필수 엔드포인트 DNS 확인 및 생성 완료"

# ---------- VPC/서브넷 태그 확인 ----------
step "서브넷 태그 확인"
# CloudFormation에서 이미 태그가 설정되어 있는지 확인
K8S_TAG_COUNT=$(aws ec2 describe-subnets --filters Name=vpc-id,Values="$APP_VPC_ID" Name=tag-key,Values="kubernetes.io/cluster/${CLUSTER_NAME}" --query 'length(Subnets)' --output text 2>/dev/null || echo "0")

if [[ "$K8S_TAG_COUNT" -gt 0 ]]; then
  ok "Kubernetes 서브넷 태그가 이미 설정됨 ($K8S_TAG_COUNT개 서브넷)"
else
  warn "Kubernetes 서브넷 태그가 없습니다. CloudFormation 템플릿을 확인하세요."
  # 백업용 태그 설정 (CloudFormation이 실패한 경우)
  info "백업용 서브넷 태그 설정 중..."
  SUBNETS=$(aws ec2 describe-subnets --filters Name=vpc-id,Values="$APP_VPC_ID" --query 'Subnets[].SubnetId' --output text)
  for s in $SUBNETS; do
    aws ec2 create-tags --resources "$s" --tags Key="kubernetes.io/cluster/${CLUSTER_NAME}",Value="shared" >/dev/null 2>&1 || true
  done
  
  # 프라이빗 서브넷에 internal-elb 태그 추가
  for name in $PRIV_SUBNET_A $PRIV_SUBNET_B; do
    id=$(aws ec2 describe-subnets --filters Name=tag:Name,Values=$name --query 'Subnets[0].SubnetId' --output text)
    if [[ "$id" != "None" && -n "$id" ]]; then
      aws ec2 create-tags --resources "$id" --tags Key="kubernetes.io/role/internal-elb",Value="1" >/dev/null 2>&1 || true
    fi
  done
  
  # 데이터 서브넷에 elb 태그 추가 (퍼블릭 로드밸런서용)
  for name in gj2025-app-data-subnet-a gj2025-app-data-subnet-b; do
    id=$(aws ec2 describe-subnets --filters Name=tag:Name,Values=$name --query 'Subnets[0].SubnetId' --output text)
    if [[ "$id" != "None" && -n "$id" ]]; then
      aws ec2 create-tags --resources "$id" --tags Key="kubernetes.io/role/elb",Value="1" >/dev/null 2>&1 || true
    fi
  done
  ok "백업용 서브넷 태그 설정 완료"
fi

DB_ENDPOINT="$(aws rds describe-db-instances --db-instance-identifier gj2025-db-instance --query 'DBInstances[0].Endpoint.Address' --output text 2>/dev/null || true)"
KMS_ID="$(aws kms list-aliases --query 'Aliases[?AliasName==`alias/gj2025/kms`].TargetKeyId' --output text || true)"
if [[ -n "${KMS_ID:-}" && "$KMS_ID" != "None" ]]; then
  ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
  KMS_ARN="arn:aws:kms:${AWS_REGION}:${ACCOUNT_ID}:key/${KMS_ID}"
else
  KMS_ARN="$(aws kms list-keys --query 'Keys[0].KeyArn' --output text || echo '')"
fi

info "S3: $BUCKET_NAME | VPC: $APP_VPC_ID"
info "SUBNET A: $SUBNET_A | SUBNET B: $SUBNET_B"
info "DB: ${DB_ENDPOINT:-N/A} | KMS: ${KMS_ARN:-alias/aws/secretsmanager}"

# ---------- 서비스 링크드 롤·OIDC 멱등 보장 ----------
step "IAM 서비스 링크드 롤 및 OIDC 설정"
# EKS 서비스 링크드 롤 생성
aws iam get-role --role-name AWSServiceRoleForEKS >/dev/null 2>&1 || \
aws iam create-service-linked-role --aws-service-name eks.amazonaws.com >/dev/null 2>&1 || true

# AutoScaling 서비스 링크드 롤 생성
aws iam get-role --role-name AWSServiceRoleForAutoScaling >/dev/null 2>&1 || \
aws iam create-service-linked-role --aws-service-name autoscaling.amazonaws.com >/dev/null 2>&1 || true

# OIDC 연결 (클러스터 생성 전에 미리 설정)
eksctl utils associate-iam-oidc-provider --cluster "$CLUSTER_NAME" --approve >/dev/null 2>&1 || true

# OIDC 연결 재적용 (경고 해소)
info "OIDC 연결 재적용 중..."
eksctl utils associate-iam-oidc-provider --cluster "$CLUSTER_NAME" --approve || true
ok "IAM 서비스 링크드 롤 및 OIDC 설정 완료"

# ---------- EKS 클러스터 ----------
step "EKS 클러스터 준비"

# CloudFormation Outputs에서 VPC/서브넷 ID 조회
APP_VPC_ID=$(aws cloudformation describe-stacks --stack-name "$CFN_STACK" --query 'Stacks[0].Outputs[?OutputKey==`AppVpcId`].OutputValue' --output text 2>/dev/null || echo "")
PRIV_SUBNET_A_ID=$(aws cloudformation describe-stacks --stack-name "$CFN_STACK" --query 'Stacks[0].Outputs[?OutputKey==`WorkloadSubnetA`].OutputValue' --output text 2>/dev/null || echo "")
PRIV_SUBNET_B_ID=$(aws cloudformation describe-stacks --stack-name "$CFN_STACK" --query 'Stacks[0].Outputs[?OutputKey==`WorkloadSubnetB`].OutputValue' --output text 2>/dev/null || echo "")
DATA_SUBNET_A_ID=$(aws cloudformation describe-stacks --stack-name "$CFN_STACK" --query 'Stacks[0].Outputs[?OutputKey==`DataSubnetA`].OutputValue' --output text 2>/dev/null || echo "")
DATA_SUBNET_B_ID=$(aws cloudformation describe-stacks --stack-name "$CFN_STACK" --query 'Stacks[0].Outputs[?OutputKey==`DataSubnetB`].OutputValue' --output text 2>/dev/null || echo "")

if [[ -z "$APP_VPC_ID" || -z "$PRIV_SUBNET_A_ID" || -z "$PRIV_SUBNET_B_ID" || -z "$DATA_SUBNET_A_ID" || -z "$DATA_SUBNET_B_ID" ]]; then
  err "CloudFormation Outputs에서 VPC/서브넷 ID를 가져올 수 없습니다."
  exit 1
fi

# Bastion Key Pair 이름 가져오기
BASTION_KEY_PAIR=$(aws cloudformation describe-stacks --stack-name "$CFN_STACK" --query 'Stacks[0].Parameters[?ParameterKey==`BastionKeyPairName`].ParameterValue' --output text 2>/dev/null || echo "default-key")
info "Bastion Key Pair: $BASTION_KEY_PAIR"

# eks.yaml 동적 생성
cat > eks.yaml <<EOF
apiVersion: eksctl.io/v1alpha5
kind: ClusterConfig

metadata:
  name: ${CLUSTER_NAME}
  region: ${AWS_REGION}
  version: "1.32"

# 컨트롤플레인 로그 5종 활성화
cloudWatch:
  clusterLogging:
    enableTypes: ["*"]
    logRetentionInDays: 7

# OIDC 사용 설정
iam:
  withOIDC: true

# VPC 설정 (CloudFormation에서 생성된 VPC 사용)
vpc:
  id: ${APP_VPC_ID}
  subnets:
    private:
      gj2025-app-private-subnet-a:
        id: ${PRIV_SUBNET_A_ID}
      gj2025-app-private-subnet-b:
        id: ${PRIV_SUBNET_B_ID}

# 관리형 노드그룹 2개
managedNodeGroups:
  # Addon 노드그룹
  - name: gj2025-eks-addon-nodegroup
    instanceType: t3.medium
    desiredCapacity: 2
    minSize: 2
    maxSize: 4
    privateNetworking: true
    labels:
      skills: addon
    tags:
      Name: gj2025-eks-addon-node
    ssh:
      allow: true
      publicKeyName: ${BASTION_KEY_PAIR}
    iam:
      withAddonPolicies:
        imageBuilder: true
        autoScaler: true
        externalDNS: true
        certManager: true
        appMesh: true
        ebs: true
        fsx: true
        cloudWatch: true

  # App 노드그룹
  - name: gj2025-eks-app-nodegroup
    instanceType: t3.medium
    desiredCapacity: 2
    minSize: 2
    maxSize: 4
    privateNetworking: true
    labels:
      skills: app
    tags:
      Name: gj2025-eks-app-node
    ssh:
      allow: true
      publicKeyName: ${BASTION_KEY_PAIR}
    iam:
      withAddonPolicies:
        imageBuilder: true
        autoScaler: true
        externalDNS: true
        certManager: true
        appMesh: true
        ebs: true
        fsx: true
        cloudWatch: true

# 추가 설정
addons:
  - name: vpc-cni
    version: latest
  - name: coredns
    version: latest
  - name: kube-proxy
    version: latest
  - name: aws-ebs-csi-driver
    version: latest
    wellKnownPolicies: { ebsCSIController: true }
EOF

if aws eks describe-cluster --name "$CLUSTER_NAME" >/dev/null 2>&1; then
  info "EKS 클러스터가 이미 존재합니다. 로깅 설정 확인 중..."; 
else
  info "EKS 생성…(수분 소요)"; 
  # 타임아웃 시간을 늘리고 재시도 로직 추가
  timeout 1800 eksctl create cluster -f eks.yaml || {
    warn "EKS 클러스터 생성 타임아웃. 수동으로 확인하세요."
    exit 1
  }
fi

# EKS 클러스터 상태 검증
CLUSTER_STATUS="$(aws eks describe-cluster --name "$CLUSTER_NAME" --query 'cluster.status' --output text 2>/dev/null || echo 'UNKNOWN')"
if [[ "$CLUSTER_STATUS" != "ACTIVE" ]]; then
  err "EKS 클러스터 상태가 비정상입니다: $CLUSTER_STATUS"
  exit 1
fi

# ---------- 클러스터 로깅(5종) 강제 활성화 ----------
step "EKS 클러스터 로깅 5종 활성화"
aws eks update-cluster-config \
  --region "$AWS_REGION" \
  --name "$CLUSTER_NAME" \
  --logging '{"clusterLogging":[{"types":["api","audit","authenticator","controllerManager","scheduler"],"enabled":true}]}' >/dev/null 2>&1 || true

# 클러스터 활성화 대기
aws eks wait cluster-active --name "$CLUSTER_NAME" --region "$AWS_REGION" || true
ok "EKS 클러스터 로깅 5종 활성화 완료"

# ---------- 노드 IAM 롤 생성·연결(없을 때만) ----------
step "노드 IAM 롤 생성 및 연결"
NODE_ROLE_NAME="gj2025-eks-node-role"
if ! aws iam get-role --role-name "$NODE_ROLE_NAME" >/dev/null 2>&1; then
  aws iam create-role --role-name "$NODE_ROLE_NAME" \
    --assume-role-policy-document '{
      "Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ec2.amazonaws.com"},"Action":"sts:AssumeRole"}]
    }' >/dev/null 2>&1 || true
  
  for pol in AmazonEKSWorkerNodePolicy AmazonEC2ContainerRegistryReadOnly AmazonEKS_CNI_Policy CloudWatchAgentServerPolicy; do
    aws iam attach-role-policy --role-name "$NODE_ROLE_NAME" --policy-arn "arn:aws:iam::aws:policy/$pol" >/dev/null 2>&1 || true
  done
fi

INSTANCE_PROFILE="gj2025-eks-node-instance-profile"
aws iam get-instance-profile --instance-profile-name "$INSTANCE_PROFILE" >/dev/null 2>&1 || \
aws iam create-instance-profile --instance-profile-name "$INSTANCE_PROFILE" >/dev/null 2>&1 || true
aws iam add-role-to-instance-profile --instance-profile-name "$INSTANCE_PROFILE" --role-name "$NODE_ROLE_NAME" >/dev/null 2>&1 || true

# ---------- 노드그룹 대기 및 진단 (eks.yaml에서 생성됨) ----------
step "노드그룹 활성화 대기 및 진단"
# 노드그룹 상태 확인 및 대기 (생성 금지)
for ng in gj2025-eks-addon-nodegroup gj2025-eks-app-nodegroup; do
  info "노드그룹 $ng 상태 확인 중..."
  NG_STATUS=$(aws eks describe-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name "$ng" --query 'nodegroup.status' --output text 2>/dev/null || echo "NOT_FOUND")
  
  if [[ "$NG_STATUS" == "NOT_FOUND" ]]; then
    err "노드그룹 $ng이 존재하지 않습니다. eks.yaml을 확인하세요."
    exit 1
  elif [[ "$NG_STATUS" == "ACTIVE" ]]; then
    info "노드그룹 $ng 이미 활성화됨"
  elif [[ "$NG_STATUS" == "CREATING" ]]; then
    info "노드그룹 $ng 생성 중... 활성화 대기 중..."
    
    # CREATING 상태가 오래 지속되는 경우 진단
    CREATING_START_TIME=$(date +%s)
    MAX_CREATING_TIME=1800  # 30분
    
    while [[ "$NG_STATUS" == "CREATING" ]]; do
      CURRENT_TIME=$(date +%s)
      ELAPSED_TIME=$((CURRENT_TIME - CREATING_START_TIME))
      
      if [[ $ELAPSED_TIME -gt $MAX_CREATING_TIME ]]; then
        warn "노드그룹 $ng이 CREATING 상태에서 30분 초과. 진단 정보 출력..."
        
        # 노드그룹 상세 정보
        info "=== 노드그룹 $ng 상세 정보 ==="
        aws eks describe-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name "$ng" --query 'nodegroup.{Status:status,DesiredSize:scalingConfig.desiredSize,CurrentSize:scalingConfig.currentSize,InstanceTypes:instanceTypes,HealthIssues:health.issues}' --output table 2>/dev/null || echo "노드그룹 정보를 가져올 수 없습니다."
        
        # 노드 상태 확인
        info "=== 노드 상태 ==="
        kubectl get nodes -o wide 2>/dev/null || echo "노드 정보를 가져올 수 없습니다."
        
        # VPC 엔드포인트 상태 확인
        info "=== VPC 엔드포인트 상태 ==="
        for service in eks ec2 ecr.api ecr.dkr sts logs; do
          ENDPOINT_STATE=$(aws ec2 describe-vpc-endpoints --filters "Name=service-name,Values=com.amazonaws.${AWS_REGION}.${service}" "Name=vpc-id,Values=$APP_VPC_ID" --query 'VpcEndpoints[0].State' --output text 2>/dev/null || echo "None")
          echo "$service: $ENDPOINT_STATE"
        done
        
        # aws-auth 확인
        info "=== aws-auth ConfigMap ==="
        kubectl get cm aws-auth -n kube-system -o yaml | grep -A 5 -B 5 "mapRoles" || echo "mapRoles 섹션 없음"
        
        err "노드그룹 $ng이 CREATING 상태에서 멈춤. 위 진단 정보를 확인하세요."
        exit 1
      fi
      
      info "노드그룹 $ng CREATING 상태... (${ELAPSED_TIME}초 경과)"
      sleep 30
      NG_STATUS=$(aws eks describe-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name "$ng" --query 'nodegroup.status' --output text 2>/dev/null || echo "UNKNOWN")
    done
    
    if [[ "$NG_STATUS" == "ACTIVE" ]]; then
      ok "노드그룹 $ng 활성화 완료"
    else
      warn "노드그룹 $ng 최종 상태: $NG_STATUS"
    fi
  else
    warn "노드그룹 $ng 상태: $NG_STATUS"
  fi
done
ok "노드그룹 활성화 대기 완료"

# ---------- 노드 조인 보장 (대기 전용, 생성 금지) ----------
step "노드 조인 보장"
aws eks update-kubeconfig --name "$CLUSTER_NAME" --region "$AWS_REGION"

# kubectl get nodes로 Ready=4 확인 루프
info "노드 조인 상태 확인 중..."
READY_NODES=0
MAX_ATTEMPTS=30
ATTEMPT=0

while [[ $READY_NODES -lt 4 && $ATTEMPT -lt $MAX_ATTEMPTS ]]; do
  READY_NODES=$(kubectl get nodes --no-headers | grep -c "Ready" || echo "0")
  info "Ready 노드 수: $READY_NODES/4 (시도 $((ATTEMPT+1))/$MAX_ATTEMPTS)"
  
  if [[ $READY_NODES -lt 4 ]]; then
    sleep 30
    ATTEMPT=$((ATTEMPT+1))
  fi
done

if [[ $READY_NODES -lt 4 ]]; then
  err "노드 조인 실패: Ready 노드 $READY_NODES개 (예상 4개)"
  info "노드그룹 이벤트 확인:"
  for ng in gj2025-eks-addon-nodegroup gj2025-eks-app-nodegroup; do
    echo "=== $ng 이벤트 ==="
    aws eks describe-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name "$ng" --query 'nodegroup.{Status:status,DesiredSize:scalingConfig.desiredSize,CurrentSize:scalingConfig.currentSize}' --output table 2>/dev/null || echo "노드그룹 $ng 정보를 가져올 수 없습니다."
  done
  exit 1
fi

ok "노드 조인 완료: Ready 노드 $READY_NODES개"
kubectl create namespace "$K8S_NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# ---------- aws-auth 보강(노드 롤 매핑 확인) ----------
step "aws-auth ConfigMap 보강"
# eksctl이 만들지 못했을 경우 대비
ROLE_ARN="$(aws iam get-role --role-name "$NODE_ROLE_NAME" --query 'Role.Arn' --output text 2>/dev/null || echo '')"
if [[ -n "$ROLE_ARN" ]]; then
  # aws-auth ConfigMap 존재 확인
  if ! kubectl get cm aws-auth -n kube-system >/dev/null 2>&1; then
    warn "aws-auth ConfigMap이 없습니다. 생성 중..."
    eksctl create iamidentitymapping --cluster "$CLUSTER_NAME" --arn "$ROLE_ARN" --username system:node:{{EC2PrivateDNSName}} --group system:bootstrappers --group system:nodes >/dev/null 2>&1 || true
  else
    # 기존 aws-auth 확인 및 노드 롤 매핑 추가
    info "aws-auth ConfigMap 확인 중..."
    if ! kubectl get cm aws-auth -n kube-system -o yaml | grep -q "$ROLE_ARN"; then
      warn "aws-auth에 노드 롤이 없습니다. 추가 중..."
      eksctl create iamidentitymapping --cluster "$CLUSTER_NAME" --arn "$ROLE_ARN" --username system:node:{{EC2PrivateDNSName}} --group system:bootstrappers --group system:nodes >/dev/null 2>&1 || true
    else
      ok "aws-auth에 노드 롤이 이미 매핑됨"
    fi
  fi
  
  # aws-auth 내용 확인
  info "aws-auth ConfigMap 내용:"
  kubectl get cm aws-auth -n kube-system -o yaml | grep -A 10 -B 5 "mapRoles" || echo "mapRoles 섹션 없음"
else
  err "노드 IAM 롤을 찾을 수 없습니다: $NODE_ROLE_NAME"
fi

# ---------- 네트워크 통신 점검(필수 엔드포인트) ----------
step "네트워크 통신 점검"
# EKS API 엔드포인트 확인
EKS_ENDPOINT="$(aws eks describe-cluster --name "$CLUSTER_NAME" --query 'cluster.endpoint' --output text 2>/dev/null || echo '')"
if [[ -n "$EKS_ENDPOINT" ]]; then
  EKS_HOST=$(echo "$EKS_ENDPOINT" | sed 's|https://||')
  nc -zv "$EKS_HOST" 443 >/dev/null 2>&1 && ok "EKS API 접근 가능" || warn "EKS API 접근 불가"
fi

# 필수 AWS 엔드포인트 DNS 확인
for ep in sts ecr.api ecr.dkr s3; do
  getent hosts "$ep.$AWS_REGION.amazonaws.com" >/dev/null 2>&1 && ok "$ep 엔드포인트 DNS 확인" || warn "$ep DNS 확인 실패"
done

# ---------- Network Firewall 허용 규칙 확인/추가 ----------
step "Network Firewall 허용 규칙 확인"
# Network Firewall이 존재하는지 확인
FIREWALL_ARN="$(aws network-firewall describe-firewall --firewall-name gj2025-firewall --query 'Firewall.FirewallArn' --output text 2>/dev/null || echo '')"

if [[ -n "$FIREWALL_ARN" ]]; then
  info "Network Firewall 확인됨: $FIREWALL_ARN"
  
  # 현재 방화벽 정책 확인
  POLICY_ARN="$(aws network-firewall describe-firewall --firewall-name gj2025-firewall --query 'Firewall.FirewallPolicyArn' --output text 2>/dev/null || echo '')"
  
  if [[ -n "$POLICY_ARN" ]]; then
    info "방화벽 정책 확인됨: $POLICY_ARN"
    
    # EKS, STS, ECR, S3 엔드포인트 허용 규칙이 있는지 확인
    CURRENT_RULES="$(aws network-firewall describe-firewall-policy --firewall-policy-arn "$POLICY_ARN" --query 'FirewallPolicyResponse.FirewallPolicy.StatelessRuleGroupReferences' --output text 2>/dev/null || echo '')"
    
    if [[ -z "$CURRENT_RULES" || "$CURRENT_RULES" == "None" ]]; then
      warn "Network Firewall에 EKS/STS/ECR/S3 허용 규칙이 없습니다."
      warn "CloudFormation 템플릿에서 다음 엔드포인트 허용 규칙을 추가하세요:"
      warn "- eks.${AWS_REGION}.amazonaws.com"
      warn "- sts.${AWS_REGION}.amazonaws.com" 
      warn "- ecr.${AWS_REGION}.amazonaws.com"
      warn "- ecr.dkr.${AWS_REGION}.amazonaws.com"
      warn "- s3.${AWS_REGION}.amazonaws.com"
    else
      ok "Network Firewall 규칙 확인됨"
    fi
  else
    warn "Network Firewall 정책을 찾을 수 없습니다."
  fi
else
  warn "Network Firewall이 존재하지 않습니다. CloudFormation에서 생성하세요."
fi

# Fargate (CoreDNS만)
if ! eksctl get fargateprofile --cluster "$CLUSTER_NAME" --name skills-fargate-profile >/dev/null 2>&1; then
  eksctl create fargateprofile --cluster "$CLUSTER_NAME" --name skills-fargate-profile \
    --namespace kube-system --labels skills=coredns || true
fi
kubectl patch deployment coredns -n kube-system --type json \
  -p='[{"op":"add","path":"/spec/template/metadata/labels/skills","value":"coredns"}]' || true

ok "EKS 클러스터 및 노드그룹 설정 완료"

# ---------- ECR & 이미지 ----------
step "ECR 및 이미지"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"

# ECR 리포지토리 생성 (KMS 암호화 명시)
aws ecr describe-repositories --repository-names "$ECR_GREEN" >/dev/null 2>&1 || \
aws ecr create-repository --repository-name "$ECR_GREEN" \
  --encryption-configuration encryptionType=KMS >/dev/null

aws ecr describe-repositories --repository-names "$ECR_RED" >/dev/null 2>&1 || \
aws ecr create-repository --repository-name "$ECR_RED" \
  --encryption-configuration encryptionType=KMS >/dev/null

# 이미지 스캔 설정
aws ecr put-image-scanning-configuration --repository-name "$ECR_GREEN" \
  --image-scanning-configuration scanOnPush=true >/dev/null 2>&1 || true

aws ecr put-image-scanning-configuration --repository-name "$ECR_RED" \
  --image-scanning-configuration scanOnPush=true >/dev/null 2>&1 || true
aws ecr get-login-password | docker login --username AWS --password-stdin "${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"

build_push(){
  local name="$1" ver="$2" bin="$3"
  if ! docker manifest inspect "${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${name}:${ver}" >/dev/null 2>&1; then
    mkdir -p "/tmp/${name}-${ver}" && pushd "/tmp/${name}-${ver}" >/dev/null
    # 바이너리 파일을 올바른 경로에서 복사
    if [[ -f "${HOME}/${bin}" ]]; then
      cp -f "${HOME}/${bin}" "./${name}"
    elif [[ -f "${PWD}/../${bin}" ]]; then
      cp -f "${PWD}/../${bin}" "./${name}"
    elif [[ -f "/home/ec2-user/${bin}" ]]; then
      cp -f "/home/ec2-user/${bin}" "./${name}"
    elif [[ -f "./${bin}" ]]; then
      cp -f "./${bin}" "./${name}"
    else
      err "바이너리 파일을 찾을 수 없습니다: ${bin}"
      popd >/dev/null
      return 1
    fi
    
    if [[ ! -f "./${name}" ]]; then
      err "바이너리 파일 복사 실패: ${name}"
      popd >/dev/null
      return 1
    fi
    cat > Dockerfile <<DF
FROM amazonlinux:2023
WORKDIR /app
COPY ${name} ./
RUN chmod +x ${name} && yum -y update
EXPOSE 8080
CMD ["./${name}"]
DF
    docker build -t "${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${name}:${ver}" .
    docker push "${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${name}:${ver}"
    popd >/dev/null
  fi
}
# 채점 버전: v1.0.0, v1.0.1 + latest
build_push green v1.0.0 green_1.0.0 || true
build_push red   v1.0.0 red_1.0.0   || true
build_push green v1.0.1 green_1.0.1 || true
build_push red   v1.0.1 red_1.0.1   || true

# latest 태그도 추가 (v1.0.1과 동일)
build_push green latest green_1.0.1 || true
build_push red   latest red_1.0.1   || true
ok "ECR 이미지 준비 완료"

# 채점용 디렉토리
mkdir -p /home/ec2-user/images/{green,red}
cat >/home/ec2-user/images/green/Dockerfile <<'DFG'
FROM amazonlinux:2023
WORKDIR /app
COPY green_1.0.1 ./app
RUN chmod +x app && yum -y update
EXPOSE 8080
CMD ["./app"]
DFG
cat >/home/ec2-user/images/red/Dockerfile <<'DFR'
FROM amazonlinux:2023
WORKDIR /app
COPY red_1.0.1 ./app
RUN chmod +x app && yum -y update
EXPOSE 8080
CMD ["./app"]
DFR

# ---------- External Secrets Operator ----------
step "External Secrets 설치"
helm repo add external-secrets https://charts.external-secrets.io >/dev/null
helm repo update >/dev/null
helm upgrade --install external-secrets external-secrets/external-secrets \
  -n external-secrets-system --create-namespace --wait \
  --set nodeSelector.skills=addon

# ---------- Secret Store CSI Driver 설치 ----------
step "Secret Store CSI Driver 설치"
helm repo add secrets-store-csi-driver https://kubernetes-sigs.github.io/secrets-store-csi-driver/charts >/dev/null
helm repo update >/dev/null
helm upgrade --install csi-secrets-store secrets-store-csi-driver/secrets-store-csi-driver \
  -n kube-system --wait \
  --set nodeSelector.skills=addon

# ---------- AWS Provider 설치 ----------
step "AWS Provider 설치"
helm repo add aws-secrets-manager https://aws.github.io/secrets-store-csi-driver-provider-aws >/dev/null
helm repo update >/dev/null
helm upgrade --install secrets-provider-aws aws-secrets-manager/secrets-store-csi-driver-provider-aws \
  -n kube-system --wait --set nodeSelector.skills=addon

# IRSA for External Secrets (최소 권한)
eksctl create iamserviceaccount \
  --cluster "$CLUSTER_NAME" --namespace "$K8S_NAMESPACE" \
  --name skills-external-secrets --role-name "$IRSA_ES_ROLE" \
  --approve --override-existing-serviceaccounts || true
aws iam put-role-policy --role-name "$IRSA_ES_ROLE" --policy-name ExternalSecretsMinimalPolicy --policy-document "$(cat <<POL
{
  "Version":"2012-10-17",
  "Statement":[{"Effect":"Allow","Action":["secretsmanager:GetSecretValue"],
    "Resource":["arn:aws:secretsmanager:${AWS_REGION}:*:secret:${CATALOG_SECRET_NAME}-*",
                "arn:aws:secretsmanager:${AWS_REGION}:*:secret:gj2025-github-token-*"]}]
}
POL
)" >/dev/null || true

# IRSA for App Pods (CSI 마운트용)
eksctl create iamserviceaccount \
  --cluster "$CLUSTER_NAME" --namespace "$K8S_NAMESPACE" \
  --name skills-app-sa --role-name SkillsAppSecretsRole \
  --attach-policy-arn arn:aws:iam::aws:policy/SecretsManagerReadWrite \
  --approve --override-existing-serviceaccounts || true

# Secrets Manager: 카탈로그 시크릿 보장
if [[ -n "${DB_ENDPOINT:-}" && "$DB_ENDPOINT" != "None" ]]; then
  if ! aws secretsmanager describe-secret --secret-id "${CATALOG_SECRET_NAME}" >/dev/null 2>&1; then
    aws secretsmanager create-secret --name "${CATALOG_SECRET_NAME}" \
      --secret-string "{\"DB_USER\":\"admin\",\"DB_PASSWORD\":\"Skills53#$%\",\"DB_URL\":\"jdbc:mysql://${DB_ENDPOINT}:3309/day1\"}" >/dev/null
  else
    aws secretsmanager update-secret --secret-id "${CATALOG_SECRET_NAME}" \
      --secret-string "{\"DB_USER\":\"admin\",\"DB_PASSWORD\":\"Skills53#$%\",\"DB_URL\":\"jdbc:mysql://${DB_ENDPOINT}:3309/day1\"}" >/dev/null
  fi
fi

# GitHub 토큰 시크릿 업데이트
if ! aws secretsmanager describe-secret --secret-id "gj2025-github-token" >/dev/null 2>&1; then
  aws secretsmanager create-secret --name "gj2025-github-token" \
    --secret-string "{\"token\":\"${GITHUB_TOKEN}\"}" >/dev/null
else
  aws secretsmanager update-secret --secret-id "gj2025-github-token" \
    --secret-string "{\"token\":\"${GITHUB_TOKEN}\"}" >/dev/null
fi

# ---------- Helm 차트 + S3 업로드 ----------
step "Helm 차트 생성/업로드"
rm -rf app && helm create app >/dev/null && rm -rf app/templates/*
cat > app/Chart.yaml <<YAML
apiVersion: v2
name: app
description: Skills Competition Application Chart
type: application
version: 0.1.0
appVersion: "1.0.0"
YAML

cat > app/templates/rollout.yaml <<'YAML'
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: {{ .Values.appName }}-rollout
  namespace: {{ .Values.namespace }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels: { app: {{ .Values.appName }} }
  template:
    metadata:
      labels: { app: {{ .Values.appName }} }
    spec:
      serviceAccountName: skills-app-sa
      nodeSelector: { skills: app }
      containers:
      - name: {{ .Values.appName }}
        image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
        ports: [ { containerPort: 8080 } ]
        env:
        - name: DB_USER
          valueFrom: { secretKeyRef: { name: db-secret, key: DB_USER } }
        - name: DB_PASSWORD
          valueFrom: { secretKeyRef: { name: db-secret, key: DB_PASSWORD } }
        - name: DB_URL
          valueFrom: { secretKeyRef: { name: db-secret, key: DB_URL } }
        volumeMounts:
        - name: secrets-store
          mountPath: "/mnt/secrets-store"
          readOnly: true
        livenessProbe:
          httpGet: { path: /health, port: 8080 }
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet: { path: /health, port: 8080 }
          initialDelaySeconds: 5
          periodSeconds: 5
        resources:
          requests: { cpu: 100m, memory: 128Mi }
          limits:   { cpu: 500m, memory: 512Mi }
      volumes:
      - name: secrets-store
        csi:
          driver: secrets-store.csi.k8s.io
          readOnly: true
          volumeAttributes:
            secretProviderClass: "gj2025-eks-cluster-catalog-secret"
  strategy:
    blueGreen:
      activeService: {{ .Values.appName }}-active
      previewService: {{ .Values.appName }}-preview
      autoPromotionEnabled: false
      scaleDownDelaySeconds: 30
YAML

cat > app/templates/svc.yaml <<'YAML'
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.appName }}-svc
  namespace: {{ .Values.namespace }}
spec:
  selector: { app: {{ .Values.appName }} }
  ports: [ { port: 80, targetPort: 8080, protocol: TCP } ]
  type: ClusterIP
---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.appName }}-active
  namespace: {{ .Values.namespace }}
spec:
  selector: { app: {{ .Values.appName }} }
  ports: [ { port: 80, targetPort: 8080, protocol: TCP } ]
  type: ClusterIP
---
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.appName }}-preview
  namespace: {{ .Values.namespace }}
spec:
  selector: { app: {{ .Values.appName }} }
  ports: [ { port: 80, targetPort: 8080, protocol: TCP } ]
  type: ClusterIP
YAML

cat > app/templates/secrets.yaml <<'YAML'
apiVersion: external-secrets.io/v1beta1
kind: SecretStore
metadata:
  name: aws-secrets-manager
  namespace: {{ .Values.namespace }}
spec:
  provider:
    aws:
      service: SecretsManager
      region: {{ .Values.awsRegion }}
      auth:
        jwt: { serviceAccountRef: { name: skills-external-secrets, namespace: {{ .Values.namespace }} } }
---
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: db-secret
  namespace: {{ .Values.namespace }}
spec:
  refreshInterval: 15s
  secretStoreRef: { name: aws-secrets-manager, kind: SecretStore }
  target:
    name: db-secret
    creationPolicy: Owner
  data:
  - secretKey: DB_USER
    remoteRef: { key: gj2025-eks-cluster-catalog-secret, property: DB_USER }
  - secretKey: DB_PASSWORD
    remoteRef: { key: gj2025-eks-cluster-catalog-secret, property: DB_PASSWORD }
  - secretKey: DB_URL
    remoteRef: { key: gj2025-eks-cluster-catalog-secret, property: DB_URL }
---
apiVersion: secrets-store.csi.x-k8s.io/v1
kind: SecretProviderClass
metadata:
  name: gj2025-eks-cluster-catalog-secret
  namespace: {{ .Values.namespace }}
spec:
  provider: aws
  parameters:
    objects: |
      - objectName: "gj2025-eks-cluster-catalog-secret"
        objectType: "secretsmanager"
        objectAlias: "catalog"
  secretObjects:
  - secretName: catalog-secret
    type: Opaque
    data:
    - objectName: catalog
      key: DB_USER
    - objectName: catalog
      key: DB_PASSWORD
    - objectName: catalog
      key: DB_URL
YAML

helm package app >/dev/null
aws s3 cp app-0.1.0.tgz "s3://${BUCKET_NAME}/app/app-0.1.0.tgz"

# Helm S3 플러그인 설치 및 초기화
helm plugin install https://github.com/hypnoglow/helm-s3.git >/dev/null 2>&1 || true
helm s3 init s3://${BUCKET_NAME}/app/ || true
helm s3 push app-0.1.0.tgz app s3://${BUCKET_NAME}/app/ || true

# ---------- GitHub 레포 구성 (values 파일) ----------
step "GitHub 저장소 구성"
if ! gh repo view "$GITHUB_USER/$GITHUB_REPO" >/dev/null 2>&1; then
  gh repo create "$GITHUB_REPO" --public --clone >/dev/null
fi
[[ -d "$GITHUB_REPO" ]] || gh repo clone "$GITHUB_USER/$GITHUB_REPO" >/dev/null
pushd "$GITHUB_REPO" >/dev/null
git config --global credential.helper store
echo "https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com" > ~/.git-credentials
git config --global user.name "$GITHUB_USER"
git config --global user.email "${GITHUB_USER}@users.noreply.github.com"
git remote set-url origin "https://${GITHUB_USER}:${GITHUB_TOKEN}@github.com/${GITHUB_USER}/${GITHUB_REPO}.git"

cat > green.values.yaml <<EOF
appName: green
namespace: ${K8S_NAMESPACE}
replicaCount: 2
image:
  repository: ${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/green
  tag: latest
awsRegion: ${AWS_REGION}
irsa:
  secretsRoleArn: arn:aws:iam::${ACCOUNT_ID}:role/${IRSA_ES_ROLE}
EOF
cat > red.values.yaml <<EOF
appName: red
namespace: ${K8S_NAMESPACE}
replicaCount: 2
image:
  repository: ${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/red
  tag: latest
awsRegion: ${AWS_REGION}
irsa:
  secretsRoleArn: arn:aws:iam::${ACCOUNT_ID}:role/${IRSA_ES_ROLE}
EOF

# GitHub 브랜치 자동 생성 (채점 기준)
git checkout -b app-red || git checkout app-red
git checkout -b gitops-red || git checkout gitops-red
git checkout -b app-green || git checkout app-green
git checkout -b gitops-green || git checkout gitops-green

# app-red 브랜치에 필요한 파일 배치
git checkout app-red
cat > Dockerfile <<'DF'
FROM amazonlinux:2023
WORKDIR /app
COPY red_1.0.1 ./red
RUN chmod +x red && yum -y update
EXPOSE 8080
CMD ["./red"]
DF

cat > buildspec.yaml <<'BS'
version: 0.2
phases:
  pre_build:
    commands:
      - echo Logging in to Amazon ECR...
      - aws ecr get-login-password --region $AWS_DEFAULT_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com
  build:
    commands:
      - echo Build started on `date`
      - echo Building the Docker image...
      - docker build -t $IMAGE_REPO_NAME:$IMAGE_TAG .
      - docker tag $IMAGE_REPO_NAME:$IMAGE_TAG $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$IMAGE_REPO_NAME:$IMAGE_TAG
  post_build:
    commands:
      - echo Build completed on `date`
      - echo Pushing the Docker image...
      - docker push $AWS_ACCOUNT_ID.dkr.ecr.$AWS_DEFAULT_REGION.amazonaws.com/$IMAGE_REPO_NAME:$IMAGE_TAG
artifacts:
  files:
    - '**/*'
BS

git add . && (git commit -m "red app cicd test" || true)
git push origin app-red || true

# app-green 브랜치에 필요한 파일 배치
git checkout app-green
cat > Dockerfile <<'DF'
FROM amazonlinux:2023
WORKDIR /app
COPY green_1.0.1 ./green
RUN chmod +x green && yum -y update
EXPOSE 8080
CMD ["./green"]
DF

cp buildspec.yaml ./
git add . && (git commit -m "green app cicd test" || true)
git push origin app-green || true

git add . && (git commit -m "values for skills chart" || true)
git push -u origin main || git push origin main || true
popd >/dev/null
ok "GitHub 브랜치 및 파일 준비 완료"

# ---------- ArgoCD 설치/플러그인(S3) ----------
step "ArgoCD 설치/설정"
kubectl create namespace argocd --dry-run=client -o yaml | kubectl apply -f -
kubectl get deploy -n argocd argocd-server >/dev/null 2>&1 || \
  kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# OIDC 연결
eksctl utils associate-iam-oidc-provider --cluster="$CLUSTER_NAME" --approve || true

# repo-server IRSA (S3 read)
eksctl create iamserviceaccount \
  --cluster "$CLUSTER_NAME" --namespace argocd --name argocd-repo-server \
  --role-name "$ARGO_REPO_ROLE" --attach-policy-arn arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess \
  --approve --override-existing-serviceaccounts || true

# helm-s3 플러그인 제공
EXIST_IMG="$(kubectl get deploy argocd-repo-server -n argocd -o jsonpath='{.spec.template.spec.containers[0].image}')"
cat > repo-patch.json <<JSON
{"spec":{"template":{"spec":{
  "serviceAccountName":"argocd-repo-server",
  "initContainers":[{"name":"dl-tools","image":"alpine:latest","command":["sh","-ec"],
    "env":[{"name":"HELM_S3_VERSION","value":"0.15.1"}],
    "args":["mkdir -p /custom-tools/helm-plugins && wget -qO- https://github.com/hypnoglow/helm-s3/releases/download/v\\${HELM_S3_VERSION}/helm-s3_\\${HELM_S3_VERSION}_linux_amd64.tar.gz | tar -xz -C /custom-tools/helm-plugins && mv /custom-tools/helm-plugins/helm-s3 /custom-tools/helm-plugins/s3"],
    "volumeMounts":[{"name":"custom-tools","mountPath":"/custom-tools"}]
  }],
  "containers":[{"name":"repo-server","image":"${EXIST_IMG}","env":[{"name":"HELM_PLUGINS","value":"/custom-tools/helm-plugins/"}],
    "volumeMounts":[{"name":"custom-tools","mountPath":"/custom-tools"}]}],
  "volumes":[{"name":"custom-tools","emptyDir":{}}]
}}}
JSON
kubectl patch deployment argocd-repo-server -n argocd --patch "$(cat repo-patch.json)" || true
kubectl rollout restart deployment/argocd-repo-server -n argocd || true

# Argo Rollouts
kubectl create namespace argo-rollouts --dry-run=client -o yaml | kubectl apply -f -
helm repo add argo https://argoproj.github.io/argo-helm >/dev/null && helm repo update >/dev/null
helm upgrade --install argo-rollouts argo/argo-rollouts -n argo-rollouts --wait

# ArgoCD 관리자 비밀번호 설정 (admin/Skills53)
# bcrypt 해시 검증 및 재패치 루틴
ARGOCD_PASSWORD_SET=false
for i in {1..5}; do
  kubectl patch secret argocd-secret -n argocd --type merge -p '{"stringData":{"admin.password":"$2a$10$rRyBsGSHK6.uc8fntPwVFOBqQyYibfZPw/iOiQyUaT8yGJ1hD9z6W","admin.passwordMtime":"'$(date +%Y-%m-%dT%H:%M:%S)'"}}' || true
  sleep 5
  # 비밀번호 검증 (ArgoCD 서버 재시작 후)
  kubectl rollout restart deployment/argocd-server -n argocd || true
  sleep 15
  if kubectl get secret argocd-secret -n argocd -o jsonpath='{.data.admin\.password}' | base64 -d | grep -q '\$2a\$10\$rRyBsGSHK6'; then
    ok "ArgoCD 비밀번호 설정 완료"
    ARGOCD_PASSWORD_SET=true
    break
  else
    warn "ArgoCD 비밀번호 설정 재시도 $i/5"
  fi
done

if [[ "$ARGOCD_PASSWORD_SET" != "true" ]]; then
  err "ArgoCD 비밀번호 설정 실패. 수동 확인이 필요합니다."
  exit 1
fi

# ---------- ArgoCD 내부 NLB 생성 ----------
step "ArgoCD 내부 NLB 생성"
cat > argocd-server-nlb.yaml <<EOF
apiVersion: v1
kind: Service
metadata:
  name: argocd-server-nlb
  namespace: argocd
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
    service.beta.kubernetes.io/aws-load-balancer-scheme: "internal"
    service.beta.kubernetes.io/aws-load-balancer-name: "gj2025-argo-internal-nlb"
    service.beta.kubernetes.io/aws-load-balancer-target-node-labels: "skills=addon"
spec:
  type: LoadBalancer
  selector:
    app.kubernetes.io/name: argocd-server
  ports:
  - port: 80
    targetPort: 8080
    protocol: TCP
EOF

kubectl apply -f argocd-server-nlb.yaml
ok "ArgoCD 내부 NLB 생성 완료"

# ---------- ArgoCD 외부 NLB 생성 ----------
step "ArgoCD 외부 NLB 생성"
cat > argocd-server-nlb-external.yaml <<EOF
apiVersion: v1
kind: Service
metadata:
  name: argocd-server-nlb-external
  namespace: argocd
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: "nlb"
    service.beta.kubernetes.io/aws-load-balancer-scheme: "internet-facing"
    service.beta.kubernetes.io/aws-load-balancer-name: "gj2025-argo-external-nlb"
    service.beta.kubernetes.io/aws-load-balancer-target-node-labels: "skills=addon"
spec:
  type: LoadBalancer
  selector:
    app.kubernetes.io/name: argocd-server
  ports:
  - port: 443
    targetPort: 8080
    protocol: TCP
EOF

kubectl apply -f argocd-server-nlb-external.yaml
ok "ArgoCD 외부 NLB 생성 완료"

# ---------- ArgoCD Application(S3 차트 + Git values) ----------
step "ArgoCD 앱 생성"
cat > argocd-green.yaml <<EOF
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata: { name: green, namespace: argocd }
spec:
  project: default
  sources:
  - repoURL: s3://${BUCKET_NAME}/app
    chart: app
    targetRevision: 0.1.0
    helm: { valueFiles: ["\\$values/green.values.yaml"] }
  - repoURL: https://github.com/${GITHUB_USER}/${GITHUB_REPO}.git
    targetRevision: HEAD
    ref: values
  destination: { server: https://kubernetes.default.svc, namespace: ${K8S_NAMESPACE} }
  syncPolicy: { automated: { prune: true, selfHeal: true } }
EOF
cat > argocd-red.yaml <<EOF
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata: { name: red, namespace: argocd }
spec:
  project: default
  sources:
  - repoURL: s3://${BUCKET_NAME}/app
    chart: app
    targetRevision: 0.1.0
    helm: { valueFiles: ["\\$values/red.values.yaml"] }
  - repoURL: https://github.com/${GITHUB_USER}/${GITHUB_REPO}.git
    targetRevision: HEAD
    ref: values
  destination: { server: https://kubernetes.default.svc, namespace: ${K8S_NAMESPACE} }
  syncPolicy: { automated: { prune: true, selfHeal: true } }
EOF
kubectl apply -f argocd-green.yaml
kubectl apply -f argocd-red.yaml
ok "ArgoCD 앱 적용"

# ---------- AWS Load Balancer Controller ----------
step "AWS Load Balancer Controller"
POLICY_URL="https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.7.2/docs/install/iam_policy.json"
curl -fsSL -o iam_policy.json "$POLICY_URL"
aws iam create-policy --policy-name AWSLoadBalancerControllerIAMPolicy \
  --policy-document file://iam_policy.json >/dev/null 2>&1 || true

eksctl create iamserviceaccount \
  --cluster "$CLUSTER_NAME" --namespace kube-system --name aws-load-balancer-controller \
  --role-name "$ALB_CTRL_ROLE" \
  --attach-policy-arn "arn:aws:iam::${ACCOUNT_ID}:policy/AWSLoadBalancerControllerIAMPolicy" \
  --approve --override-existing-serviceaccounts || true

cat > alb-values.yaml <<EOF
clusterName: ${CLUSTER_NAME}
serviceAccount:
  create: false
  name: aws-load-balancer-controller
nodeSelector:
  skills: addon
EOF
helm repo add eks https://aws.github.io/eks-charts >/dev/null && helm repo update >/dev/null
helm upgrade --install aws-load-balancer-controller eks/aws-load-balancer-controller \
  -n kube-system -f alb-values.yaml

# ---------- Ingress (ALB) ----------
step "ALB Ingress"
SUBNET_A_ID="$SUBNET_A"; SUBNET_B_ID="$SUBNET_B"
cat > ingress.yaml <<EOF
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: gj2025-app-ingress
  namespace: ${K8S_NAMESPACE}
  annotations:
    alb.ingress.kubernetes.io/scheme: internal
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP":80}]'
    alb.ingress.kubernetes.io/load-balancer-name: ${ALB_NAME}
    alb.ingress.kubernetes.io/subnets: ${SUBNET_A_ID},${SUBNET_B_ID}
spec:
  ingressClassName: alb
  rules:
  - http:
      paths:
      - path: /green
        pathType: Prefix
        backend: { service: { name: green-svc, port: { number: 80 } } }
      - path: /red
        pathType: Prefix
        backend: { service: { name: red-svc, port: { number: 80 } } }
EOF
kubectl apply -f ingress.yaml

# ---------- TGW Associations (CFn 리소스명 고정) ----------
step "Transit Gateway Association"
HUB_RTB_ID="$(aws cloudformation describe-stack-resources --stack-name "$CFN_STACK" --query "StackResources[?LogicalResourceId=='${TGW_RTB_HUB}'].PhysicalResourceId" --output text || true)"
APP_RTB_ID="$(aws cloudformation describe-stack-resources --stack-name "$CFN_STACK" --query "StackResources[?LogicalResourceId=='${TGW_RTB_APP}'].PhysicalResourceId" --output text || true)"
HUB_ATTACH_ID="$(aws cloudformation describe-stack-resources --stack-name "$CFN_STACK" --query "StackResources[?LogicalResourceId=='${TGW_ATTACH_HUB}'].PhysicalResourceId" --output text || true)"
APP_ATTACH_ID="$(aws cloudformation describe-stack-resources --stack-name "$CFN_STACK" --query "StackResources[?LogicalResourceId=='${TGW_ATTACH_APP}'].PhysicalResourceId" --output text || true)"
if [[ -n "$HUB_RTB_ID" && -n "$APP_RTB_ID" && -n "$HUB_ATTACH_ID" && -n "$APP_ATTACH_ID" ]]; then
  aws ec2 replace-transit-gateway-route-table-association --transit-gateway-attachment-id "$HUB_ATTACH_ID" --transit-gateway-route-table-id "$HUB_RTB_ID" || true
  aws ec2 replace-transit-gateway-route-table-association --transit-gateway-attachment-id "$APP_ATTACH_ID" --transit-gateway-route-table-id "$APP_RTB_ID" || true
else
  warn "TGW 리소스 일부 누락 - CloudFormation 스택/이름 확인"
fi

# ---------- ALB → Internal NLB → External NLB 체인 ----------
step "LB 체인 구성"
ALB_ARN="$(aws elbv2 describe-load-balancers --names "${ALB_NAME}" --query 'LoadBalancers[0].LoadBalancerArn' --output text 2>/dev/null || true)"
INTERNAL_TG_ARN="$(aws elbv2 describe-target-groups --names "${INTERNAL_TG_NAME}" --query 'TargetGroups[0].TargetGroupArn' --output text 2>/dev/null || true)"
if [[ -n "$ALB_ARN" && -n "$INTERNAL_TG_ARN" ]]; then
  ENIS="$(aws ec2 describe-network-interfaces --filters Name=description,Values="ELB app/${ALB_NAME}/*" --query 'NetworkInterfaces[].NetworkInterfaceId' --output text || true)"
  if [[ -n "$ENIS" ]]; then
    IPS="$(aws ec2 describe-network-interfaces --network-interface-ids ${ENIS} --query 'NetworkInterfaces[].PrivateIpAddress' --output text || true)"
  for ip in $IPS; do aws elbv2 register-targets --target-group-arn "$INTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
  
  # 내부 NLB 타겟 등록 확인 및 재시도 루프
  INTERNAL_SUCCESS=false
  for retry in {1..5}; do
    sleep 10
    HEALTH_COUNT="$(aws elbv2 describe-target-health --target-group-arn "$INTERNAL_TG_ARN" --query 'TargetHealthDescriptions[?TargetHealth.State==`healthy`] | length(@)' --output text 2>/dev/null || echo 0)"
    if [[ "$HEALTH_COUNT" -gt 0 ]]; then
      ok "내부 NLB 타겟 등록 완료 (healthy: $HEALTH_COUNT)"
      INTERNAL_SUCCESS=true
      break
    else
      warn "내부 NLB 타겟 등록 재시도 $retry/5"
      # 재등록 시도
    for ip in $IPS; do aws elbv2 register-targets --target-group-arn "$INTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
    fi
  done
  
  # 내부 NLB 실패 시 롤백
  if [[ "$INTERNAL_SUCCESS" != "true" ]]; then
    warn "내부 NLB 타겟 등록 실패. 등록 해제 후 재시도..."
    for ip in $IPS; do aws elbv2 deregister-targets --target-group-arn "$INTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
    sleep 30
    for ip in $IPS; do aws elbv2 register-targets --target-group-arn "$INTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
  fi
  fi
fi
EXTERNAL_TG_ARN="$(aws elbv2 describe-target-groups --names "${EXTERNAL_TG_NAME}" --query 'TargetGroups[0].TargetGroupArn' --output text 2>/dev/null || true)"
INTERNAL_NLB_ARN="$(aws elbv2 describe-load-balancers --names "${INTERNAL_NLB_NAME}" --query 'LoadBalancers[0].LoadBalancerArn' --output text 2>/dev/null || true)"
if [[ -n "$EXTERNAL_TG_ARN" && -n "$INTERNAL_NLB_ARN" ]]; then
  # NLB ENI의 Private IP 조회 (고정 IP 없을 경우 대비)
  INLB_ENIS="$(aws elbv2 describe-load-balancers --load-balancer-arns "$INTERNAL_NLB_ARN" --query 'LoadBalancers[0].AvailabilityZones[].LoadBalancerAddresses[0].AllocationId' --output text 2>/dev/null || true)"
  if [[ -z "$INLB_ENIS" || "$INLB_ENIS" == "None" ]]; then
    # ENI 기반으로 Private IP 조회
    INLB_ENIS="$(aws ec2 describe-network-interfaces --filters Name=description,Values="ELB app/${INTERNAL_NLB_NAME}/*" --query 'NetworkInterfaces[].NetworkInterfaceId' --output text || true)"
  fi
  if [[ -n "$INLB_ENIS" ]]; then
    INLB_IPS="$(aws ec2 describe-network-interfaces --network-interface-ids $INLB_ENIS --query 'NetworkInterfaces[].PrivateIpAddress' --output text || true)"
    for ip in $INLB_IPS; do aws elbv2 register-targets --target-group-arn "$EXTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
    
    # 타겟 등록 확인 및 재시도 루프 (내부와 동일한 전략)
    EXTERNAL_SUCCESS=false
    for retry in {1..5}; do
      sleep 10
      HEALTH_COUNT="$(aws elbv2 describe-target-health --target-group-arn "$EXTERNAL_TG_ARN" --query 'TargetHealthDescriptions[?TargetHealth.State==`healthy`] | length(@)' --output text 2>/dev/null || echo 0)"
      if [[ "$HEALTH_COUNT" -gt 0 ]]; then
        ok "외부 NLB 타겟 등록 완료 (healthy: $HEALTH_COUNT)"
        EXTERNAL_SUCCESS=true
        break
      else
        warn "외부 NLB 타겟 등록 재시도 $retry/5"
        # 재등록 시도
  for ip in $INLB_IPS; do aws elbv2 register-targets --target-group-arn "$EXTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
      fi
    done
    
    # 외부 NLB 실패 시 롤백
    if [[ "$EXTERNAL_SUCCESS" != "true" ]]; then
      warn "외부 NLB 타겟 등록 실패. 등록 해제 후 재시도..."
      for ip in $INLB_IPS; do aws elbv2 deregister-targets --target-group-arn "$EXTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
      sleep 30
      for ip in $INLB_IPS; do aws elbv2 register-targets --target-group-arn "$EXTERNAL_TG_ARN" --targets "Id=$ip,Port=80" || true; done
    fi
  fi
fi

# ---------- 롤아웃 리소스(Blue/Green) ----------
step "Argo Rollouts 리소스"
# Helm 템플릿에서 Rollout을 생성하므로 별도 rollouts.yaml 제거
# 서비스 충돌 방지를 위해 Helm 템플릿만 사용

# 롤아웃 전 노드 상태 확인
info "롤아웃 전 노드 상태 확인"
kubectl get nodes -o wide
echo ""

# 노드그룹 이벤트 확인
info "노드그룹 이벤트 확인"
for ng in gj2025-eks-addon-nodegroup gj2025-eks-app-nodegroup; do
  echo "=== $ng 노드그룹 상태 ==="
  aws eks describe-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name "$ng" --query 'nodegroup.{Status:status,DesiredSize:scalingConfig.desiredSize,CurrentSize:scalingConfig.currentSize,InstanceTypes:instanceTypes}' --output table 2>/dev/null || echo "노드그룹 $ng 정보를 가져올 수 없습니다."
  echo ""
done

# 롤아웃 상태 확인 및 대기
info "롤아웃 상태 확인 중..."
kubectl get rollout red-rollout -n "$K8S_NAMESPACE" >/dev/null 2>&1 && {
  info "red-rollout 롤아웃 확인 중..."
  kubectl rollout status rollout/red-rollout -n "$K8S_NAMESPACE" --timeout=300s || warn "red-rollout 상태 확인 시간 초과"
}

kubectl get rollout green-rollout -n "$K8S_NAMESPACE" >/dev/null 2>&1 && {
  info "green-rollout 롤아웃 확인 중..."
  kubectl rollout status rollout/green-rollout -n "$K8S_NAMESPACE" --timeout=300s || warn "green-rollout 상태 확인 시간 초과"
}

ok "Argo Rollouts 리소스는 Helm 템플릿에서 처리됨"

# ---------- 로깅(필수 채점 필드 최소 구성) ----------
step "Logging(CloudWatch)"
kubectl create namespace amazon-cloudwatch --dry-run=client -o yaml | kubectl apply -f -

# Red FluentBit (HTTP Method 로그만, /health 제외)
cat > red-fluent-bit.yaml <<EOF
apiVersion: apps/v1
kind: DaemonSet
metadata: 
  name: red-fluent-bit
  namespace: amazon-cloudwatch
  labels: { app: red-fluent-bit }
spec:
  selector: { matchLabels: { app: red-fluent-bit } }
  template:
    metadata: { labels: { app: red-fluent-bit } }
    spec:
      nodeSelector: { skills: app }
      containers:
      - name: fluent-bit
        image: amazon/aws-for-fluent-bit:latest
        env: 
        - { name: AWS_REGION, value: "${AWS_REGION}" }
        - { name: FLB_LOG_LEVEL, value: "info" }
        volumeMounts: 
        - { name: varlog, mountPath: /var/log }
        - { name: fluent-bit-config, mountPath: /fluent-bit/etc }
        args: ["/fluent-bit/bin/fluent-bit", "-c", "/fluent-bit/etc/fluent-bit.conf"]
      volumes: 
      - { name: varlog, hostPath: { path: /var/log } }
      - { name: fluent-bit-config, configMap: { name: red-fluent-bit-config } }
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: red-fluent-bit-config
  namespace: amazon-cloudwatch
data:
  fluent-bit.conf: |
    [SERVICE]
        Flush                     5
        Grace                     30
        Log_Level                 info
        Daemon                    off
        HTTP_Server               On
        HTTP_Listen               0.0.0.0
        HTTP_Port                 2020
        storage.path              /var/fluent-bit/state/flb-storage/
        storage.sync              normal
        storage.checksum          off
        storage.backlog.mem_limit 5M

    [INPUT]
        Name                tail
        Tag                 red.*
        Path                /var/log/containers/*red*
        multiline.parser    docker, cri
        DB                  /var/fluent-bit/state/flb_container.db
        Mem_Buf_Limit       50MB
        Skip_Long_Lines     On
        Refresh_Interval    10
        Rotate_Wait         30
        storage.type        filesystem
        Read_from_Head      false

    [FILTER]
        Name    parser
        Match   red.*
        Key_name log
        Parser  json
        Reserve_Data On

    [FILTER]
        Name    grep
        Match   red.*
        Regex   log .*GET.*|.*POST.*
        Exclude log /health

    [OUTPUT]
        Name                cloudwatch_logs
        Match               red.*
        region              ${AWS_REGION}
        log_group_name      /gj2025/app/red
        log_stream_name     app-red-logs
        auto_create_group   true
EOF

# Green FluentBit
cat > green-fluent-bit.yaml <<EOF
apiVersion: apps/v1
kind: DaemonSet
metadata: 
  name: green-fluent-bit
  namespace: amazon-cloudwatch
  labels: { app: green-fluent-bit }
spec:
  selector: { matchLabels: { app: green-fluent-bit } }
  template:
    metadata: { labels: { app: green-fluent-bit } }
    spec:
      nodeSelector: { skills: app }
      containers:
      - name: fluent-bit
        image: amazon/aws-for-fluent-bit:latest
        env: 
        - { name: AWS_REGION, value: "${AWS_REGION}" }
        - { name: FLB_LOG_LEVEL, value: "info" }
        volumeMounts: 
        - { name: varlog, mountPath: /var/log }
        - { name: fluent-bit-config, mountPath: /fluent-bit/etc }
        args: ["/fluent-bit/bin/fluent-bit", "-c", "/fluent-bit/etc/fluent-bit.conf"]
      volumes: 
      - { name: varlog, hostPath: { path: /var/log } }
      - { name: fluent-bit-config, configMap: { name: green-fluent-bit-config } }
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: green-fluent-bit-config
  namespace: amazon-cloudwatch
data:
  fluent-bit.conf: |
    [SERVICE]
        Flush                     5
        Grace                     30
        Log_Level                 info
        Daemon                    off
        HTTP_Server               On
        HTTP_Listen               0.0.0.0
        HTTP_Port                 2020
        storage.path              /var/fluent-bit/state/flb-storage/
        storage.sync              normal
        storage.checksum          off
        storage.backlog.mem_limit 5M

    [INPUT]
        Name                tail
        Tag                 green.*
        Path                /var/log/containers/*green*
        multiline.parser    docker, cri
        DB                  /var/fluent-bit/state/flb_container.db
        Mem_Buf_Limit       50MB
        Skip_Long_Lines     On
        Refresh_Interval    10
        Rotate_Wait         30
        storage.type        filesystem
        Read_from_Head      false

    [FILTER]
        Name    parser
        Match   green.*
        Key_name log
        Parser  json
        Reserve_Data On

    [FILTER]
        Name    grep
        Match   green.*
        Regex   log .*GET.*|.*POST.*
        Exclude log /health

    [OUTPUT]
        Name                cloudwatch_logs
        Match               green.*
        region              ${AWS_REGION}
        log_group_name      /gj2025/app/green
        log_stream_name     app-green-logs
        auto_create_group   true
EOF

kubectl apply -f red-fluent-bit.yaml
kubectl apply -f green-fluent-bit.yaml

# ---------- CloudWatch 로그 그룹 사전 생성 ----------
step "CloudWatch 로그 그룹 생성"
for log_group in "/gj2025/build/red" "/gj2025/build/green" "/gj2025/app/red" "/gj2025/app/green"; do
  aws logs create-log-group --log-group-name "$log_group" --retention-in-days 7 >/dev/null 2>&1 || true
done
ok "CloudWatch 로그 그룹 생성 완료"

# ---------- IAM 역할 및 정책 생성 ----------
step "IAM 역할 및 정책 생성"

# CodeBuild 서비스 역할 생성
aws iam create-role --role-name CodeBuildServiceRole --assume-role-policy-document '{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"Service": "codebuild.amazonaws.com"},
    "Action": "sts:AssumeRole"
  }]
}' >/dev/null 2>&1 || true

# CodeBuild 정책 생성
aws iam put-role-policy --role-name CodeBuildServiceRole --policy-name CodeBuildPolicy --policy-document '{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage",
        "ecr:PutImage",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": "secretsmanager:GetSecretValue",
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogGroups"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::'${BUCKET_NAME}'/*"
    }
  ]
}' >/dev/null 2>&1 || true

# CodePipeline 서비스 역할 생성
aws iam create-role --role-name CodePipelineServiceRole --assume-role-policy-document '{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"Service": "codepipeline.amazonaws.com"},
    "Action": "sts:AssumeRole"
  }]
}' >/dev/null 2>&1 || true

# CodePipeline 정책 생성
aws iam put-role-policy --role-name CodePipelineServiceRole --policy-name CodePipelinePolicy --policy-document '{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:DeleteObject"
      ],
      "Resource": "arn:aws:s3:::'${BUCKET_NAME}'/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "codebuild:BatchGetBuilds",
        "codebuild:StartBuild"
      ],
      "Resource": "arn:aws:codebuild:*:*:project/gj2025-app-*"
    },
    {
      "Effect": "Allow",
      "Action": "sts:PassRole",
      "Resource": "arn:aws:iam::'${ACCOUNT_ID}':role/CodeBuildServiceRole"
    },
    {
      "Effect": "Allow",
      "Action": "codestar-connections:UseConnection",
      "Resource": "arn:aws:codestar-connections:*:*:connection/*gj2025-github-connection*"
    }
  ]
}' >/dev/null 2>&1 || true

ok "IAM 역할 및 정책 생성 완료"

# ---------- CodeBuild/CodePipeline (CI/CD) ----------
step "CodeBuild/CodePipeline 구성"

# GitHub OAuth 연결
CONNECTION_ARN=$(aws codestar-connections create-connection \
  --provider-type GitHub \
  --connection-name gj2025-github-connection \
  --query 'ConnectionArn' --output text 2>/dev/null || \
  aws codestar-connections list-connections \
  --query 'Connections[?ConnectionName==`gj2025-github-connection`].ConnectionArn' \
  --output text | head -1)

# CodeStar Connections 승인 상태 확인
if [[ -n "$CONNECTION_ARN" ]]; then
  CONNECTION_STATUS="$(aws codestar-connections get-connection --connection-arn "$CONNECTION_ARN" --query 'Connection.ConnectionStatus' --output text 2>/dev/null || echo 'UNKNOWN')"
  if [[ "$CONNECTION_STATUS" == "PENDING" ]]; then
    err "CodeStar Connections가 승인 대기 중입니다. AWS 콘솔에서 연결을 승인한 후 다시 실행하세요."
    err "연결 ARN: $CONNECTION_ARN"
    exit 1
  elif [[ "$CONNECTION_STATUS" == "AVAILABLE" ]]; then
    ok "CodeStar Connections 승인 완료"
  else
    warn "CodeStar Connections 상태: $CONNECTION_STATUS"
  fi
fi

# Red CodeBuild 프로젝트
cat > red-build-project.json <<EOF
{
  "name": "gj2025-app-red-build",
  "source": {
    "type": "CODEPIPELINE",
    "buildspec": "buildspec.yaml"
  },
  "artifacts": {
    "type": "NO_ARTIFACTS"
  },
  "environment": {
    "type": "LINUX_CONTAINER",
    "image": "aws/codebuild/amazonlinux2-x86_64-standard:5.0",
    "computeType": "BUILD_GENERAL1_SMALL",
    "privilegedMode": true,
    "environmentVariables": [
      {
        "name": "AWS_DEFAULT_REGION",
        "value": "${AWS_REGION}"
      },
      {
        "name": "AWS_ACCOUNT_ID", 
        "value": "${ACCOUNT_ID}"
      },
      {
        "name": "IMAGE_REPO_NAME",
        "value": "red"
      },
      {
        "name": "IMAGE_TAG",
        "value": "latest"
      },
      {
        "name": "GITHUB_TOKEN",
        "type": "SECRETS_MANAGER",
        "value": "gj2025-github-token:token"
      },
      {
        "name": "ECR_REGISTRY",
        "value": "${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
      }
    ]
  },
  "serviceRole": "arn:aws:iam::${ACCOUNT_ID}:role/CodeBuildServiceRole",
  "logsConfig": {
    "cloudWatchLogs": {
      "status": "ENABLED",
      "groupName": "/gj2025/build/red"
    }
  }
}
EOF

# Green CodeBuild 프로젝트  
cat > green-build-project.json <<EOF
{
  "name": "gj2025-app-green-build",
  "source": {
    "type": "CODEPIPELINE",
    "buildspec": "buildspec.yaml"
  },
  "artifacts": {
    "type": "NO_ARTIFACTS"
  },
  "environment": {
    "type": "LINUX_CONTAINER",
    "image": "aws/codebuild/amazonlinux2-x86_64-standard:5.0",
    "computeType": "BUILD_GENERAL1_SMALL",
    "privilegedMode": true,
    "environmentVariables": [
      {
        "name": "AWS_DEFAULT_REGION",
        "value": "${AWS_REGION}"
      },
      {
        "name": "AWS_ACCOUNT_ID",
        "value": "${ACCOUNT_ID}"
      },
      {
        "name": "IMAGE_REPO_NAME",
        "value": "green"
      },
      {
        "name": "IMAGE_TAG",
        "value": "latest"
      },
      {
        "name": "GITHUB_TOKEN",
        "type": "SECRETS_MANAGER",
        "value": "gj2025-github-token:token"
      },
      {
        "name": "ECR_REGISTRY",
        "value": "${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
      }
    ]
  },
  "serviceRole": "arn:aws:iam::${ACCOUNT_ID}:role/CodeBuildServiceRole",
  "logsConfig": {
    "cloudWatchLogs": {
      "status": "ENABLED",
      "groupName": "/gj2025/build/green"
    }
  }
}
EOF

# CodeBuild 프로젝트 생성 (멱등성 보장)
step "CodeBuild 프로젝트 생성"
# Red 프로젝트 생성/업데이트
if aws codebuild batch-get-projects --names gj2025-app-red-build >/dev/null 2>&1; then
  info "Red CodeBuild 프로젝트가 이미 존재합니다. 업데이트 중..."
  aws codebuild update-project --cli-input-json file://red-build-project.json >/dev/null
else
  info "Red CodeBuild 프로젝트 생성 중..."
  aws codebuild create-project --cli-input-json file://red-build-project.json >/dev/null
fi

# Green 프로젝트 생성/업데이트
if aws codebuild batch-get-projects --names gj2025-app-green-build >/dev/null 2>&1; then
  info "Green CodeBuild 프로젝트가 이미 존재합니다. 업데이트 중..."
  aws codebuild update-project --cli-input-json file://green-build-project.json >/dev/null
else
  info "Green CodeBuild 프로젝트 생성 중..."
  aws codebuild create-project --cli-input-json file://green-build-project.json >/dev/null
fi
ok "CodeBuild 프로젝트 생성/업데이트 완료"

# CodePipeline 생성
cat > red-pipeline.json <<EOF
{
  "pipeline": {
    "name": "gj2025-app-red-pipeline",
    "roleArn": "arn:aws:iam::${ACCOUNT_ID}:role/CodePipelineServiceRole",
    "artifactStore": {
      "type": "S3",
      "location": "${BUCKET_NAME}"
    },
    "stages": [
      {
        "name": "Source",
        "actions": [
          {
            "name": "SourceAction",
            "actionTypeId": {
              "category": "Source",
              "owner": "AWS",
              "provider": "CodeStarSourceConnection",
              "version": "1"
            },
        "configuration": {
          "ConnectionArn": "${CONNECTION_ARN}",
          "FullRepositoryId": "${GITHUB_USER}/${GITHUB_REPO}",
          "BranchName": "app-red"
        },
            "outputArtifacts": [
              {
                "name": "SourceOutput"
              }
            ]
          }
        ]
      },
      {
        "name": "Build",
        "actions": [
          {
            "name": "BuildAction",
            "actionTypeId": {
              "category": "Build",
              "owner": "AWS", 
              "provider": "CodeBuild",
              "version": "1"
            },
            "configuration": {
              "ProjectName": "gj2025-app-red-build"
            },
            "inputArtifacts": [
              {
                "name": "SourceOutput"
              }
            ]
          }
        ]
      }
    ]
  }
}
EOF

cat > green-pipeline.json <<EOF
{
  "pipeline": {
    "name": "gj2025-app-green-pipeline", 
    "roleArn": "arn:aws:iam::${ACCOUNT_ID}:role/CodePipelineServiceRole",
    "artifactStore": {
      "type": "S3",
      "location": "${BUCKET_NAME}"
    },
    "stages": [
      {
        "name": "Source",
        "actions": [
          {
            "name": "SourceAction",
            "actionTypeId": {
              "category": "Source",
              "owner": "AWS",
              "provider": "CodeStarSourceConnection", 
              "version": "1"
            },
        "configuration": {
          "ConnectionArn": "${CONNECTION_ARN}",
          "FullRepositoryId": "${GITHUB_USER}/${GITHUB_REPO}",
          "BranchName": "app-green"
        },
            "outputArtifacts": [
              {
                "name": "SourceOutput"
              }
            ]
          }
        ]
      },
      {
        "name": "Build",
        "actions": [
          {
            "name": "BuildAction",
            "actionTypeId": {
              "category": "Build",
              "owner": "AWS",
              "provider": "CodeBuild",
              "version": "1"
            },
            "configuration": {
              "ProjectName": "gj2025-app-green-build"
            },
            "inputArtifacts": [
              {
                "name": "SourceOutput"
              }
            ]
          }
        ]
      }
    ]
  }
}
EOF

# CodePipeline 생성 (멱등성 보장)
step "CodePipeline 생성"
# Red 파이프라인 생성/업데이트
if aws codepipeline get-pipeline --name gj2025-app-red-pipeline >/dev/null 2>&1; then
  info "Red CodePipeline이 이미 존재합니다. 업데이트 중..."
  aws codepipeline update-pipeline --cli-input-json file://red-pipeline.json >/dev/null
else
  info "Red CodePipeline 생성 중..."
  aws codepipeline create-pipeline --cli-input-json file://red-pipeline.json >/dev/null
fi

# Green 파이프라인 생성/업데이트
if aws codepipeline get-pipeline --name gj2025-app-green-pipeline >/dev/null 2>&1; then
  info "Green CodePipeline이 이미 존재합니다. 업데이트 중..."
  aws codepipeline update-pipeline --cli-input-json file://green-pipeline.json >/dev/null
else
  info "Green CodePipeline 생성 중..."
  aws codepipeline create-pipeline --cli-input-json file://green-pipeline.json >/dev/null
fi
ok "CodePipeline 생성/업데이트 완료"

ok "CodeBuild/CodePipeline 구성 완료"

# ---------- ArgoCD NLB 연결 ----------
step "ArgoCD NLB 연결 확인"

# ArgoCD External NLB 확인
ARGO_EXTERNAL_NLB=$(aws elbv2 describe-load-balancers \
  --names gj2025-argo-external-nlb \
  --query "LoadBalancers[0].DNSName" \
  --output text 2>/dev/null || echo "N/A")

# ArgoCD Internal NLB 확인  
ARGO_INTERNAL_NLB=$(aws elbv2 describe-load-balancers \
  --names gj2025-argo-internal-nlb \
  --query "LoadBalancers[0].DNSName" \
  --output text 2>/dev/null || echo "N/A")

if [[ "$ARGO_EXTERNAL_NLB" != "N/A" ]]; then
  info "ArgoCD External NLB: $ARGO_EXTERNAL_NLB"
  # ArgoCD 접근 테스트 (admin/Skills53)
  curl -k -s https://$ARGO_EXTERNAL_NLB >/dev/null && ok "ArgoCD External NLB 접근 가능" || warn "ArgoCD External NLB 접근 실패"
fi

if [[ "$ARGO_INTERNAL_NLB" != "N/A" ]]; then
  info "ArgoCD Internal NLB: $ARGO_INTERNAL_NLB"
fi

# ---------- 최종 검증 ----------
step "최종 검증"
# EKS 클러스터 상태 확인
CLUSTER_STATUS="$(aws eks describe-cluster --name "$CLUSTER_NAME" --query 'cluster.status' --output text 2>/dev/null || echo 'UNKNOWN')"
if [[ "$CLUSTER_STATUS" == "ACTIVE" ]]; then
  ok "EKS 클러스터 상태: $CLUSTER_STATUS"
else
  warn "EKS 클러스터 상태: $CLUSTER_STATUS"
fi

# 노드그룹 상태 확인
for ng in gj2025-eks-addon-nodegroup gj2025-eks-app-nodegroup; do
  NG_STATUS="$(aws eks describe-nodegroup --cluster-name "$CLUSTER_NAME" --nodegroup-name "$ng" --query 'nodegroup.status' --output text 2>/dev/null || echo 'NOT_FOUND')"
  if [[ "$NG_STATUS" == "ACTIVE" ]]; then
    ok "노드그룹 $ng 상태: $NG_STATUS"
  else
    warn "노드그룹 $ng 상태: $NG_STATUS"
  fi
done

# 롤아웃 상태 확인
kubectl get rollout red-rollout -n "$K8S_NAMESPACE" >/dev/null 2>&1 && {
  RED_STATUS="$(kubectl get rollout red-rollout -n "$K8S_NAMESPACE" -o jsonpath='{.status.phase}' 2>/dev/null || echo 'Unknown')"
  ok "red-rollout 상태: $RED_STATUS"
} || warn "red-rollout 없음"

kubectl get rollout green-rollout -n "$K8S_NAMESPACE" >/dev/null 2>&1 && {
  GREEN_STATUS="$(kubectl get rollout green-rollout -n "$K8S_NAMESPACE" -o jsonpath='{.status.phase}' 2>/dev/null || echo 'Unknown')"
  ok "green-rollout 상태: $GREEN_STATUS"
} || warn "green-rollout 없음"

# External Secret 상태 확인
kubectl get externalsecret db-secret -n "$K8S_NAMESPACE" >/dev/null 2>&1 && {
  ES_STATUS="$(kubectl get externalsecret db-secret -n "$K8S_NAMESPACE" -o jsonpath='{.status.conditions[0].status}' 2>/dev/null || echo 'Unknown')"
  ok "External Secret 상태: $ES_STATUS"
} || warn "External Secret 없음"

# ---------- 최종 환경변수/요약 ----------
step "환경 정리"
{
  echo ""; echo "# Skills Competition 2025"
  echo "export BUCKET_NAME=${BUCKET_NAME}"
  echo "export GITHUB_USER=${GITHUB_USER}"
  echo "export AWS_DEFAULT_REGION=${AWS_REGION}"
  echo "export CLUSTER_NAME=${CLUSTER_NAME}"
  echo "export K8S_NAMESPACE=${K8S_NAMESPACE}"
} >> ~/.bashrc

ok "모든 단계 완료"
info "S3: ${BUCKET_NAME}"
info "EKS: ${CLUSTER_NAME}"
info "GitHub: https://github.com/${GITHUB_USER}/${GITHUB_REPO}"
info "Namespace: ${K8S_NAMESPACE}"

# 채점 스크립트 실행 안내
echo ""
warn "채점을 위해 다음 명령어를 실행하세요:"
echo "bash /home/ec2-user/marking.sh"
