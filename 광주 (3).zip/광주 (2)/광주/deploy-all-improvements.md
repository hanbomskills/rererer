# Deploy-All.sh 주요 개선사항

## 1. CodeBuild/CodePipeline 추가
```bash
# GitHub OAuth 연결
aws codestar-connections create-connection \
  --provider-type GitHub \
  --connection-name gj2025-github-connection

# CodeBuild 프로젝트 생성
aws codebuild create-project \
  --name gj2025-app-red-build \
  --source type=GITHUB \
  --source location=https://github.com/$(GITHUB_USER)/$(GITHUB_REPO).git \
  --source auth=SECRETS_MANAGER \
  --environment type=LINUX_CONTAINER \
  --logs cloudWatchLogs=groupName=/gj2025/build/red

# CodePipeline 생성
aws codepipeline create-pipeline \
  --pipeline-name gj2025-app-red-pipeline \
  --role-arn $(ROLE_ARN) \
  --stages source-stage,build-stage
```

## 2. ArgoCD NLB 연결
```bash
# ArgoCD External NLB 확인
ARGO_EXTERNAL_NLB=$(aws elbv2 describe-load-balancers \
  --names gj2025-argo-external-nlb \
  --query "LoadBalancers[0].DNSName" \
  --output text)

# ArgoCD 접근 테스트
curl -k https://$ARGO_EXTERNAL_NLB
```

## 3. GitHub 브랜치 자동 생성
```bash
# 브랜치 생성
git checkout -b app-red
git checkout -b gitops-red  
git checkout -b app-green
git checkout -b gitops-green

# 각 브랜치에 필요한 파일 배치
# app-red: red 바이너리, Dockerfile, buildspec.yaml
# gitops-red: values.yaml
```

## 4. FluentBit 로깅 구성
```bash
# HTTP Method 로그만 전송하도록 설정
cat > fluent-bit-config.yaml <<EOF
[FILTER]
Name parser
Match *
Key_name log
Parser json
Reserve_Data On

[FILTER]
Name grep
Match *
Regex log .*GET.*|.*POST.*
exclude log /health

[OUTPUT]
Name cloudwatch_logs
Match *
region $(AWS_REGION)
log_group_name /gj2025/app/red
log_stream_name app-red-logs
EOF
```

## 5. Secrets Manager 업데이트
```bash
# DB 연결 정보 업데이트
aws secretsmanager update-secret \
  --secret-id gj2025-eks-cluster-catalog-secret \
  --secret-string '{"DB_USER":"admin","DB_PASSWORD":"Skills53#$%","DB_URL":"jdbc:mysql://$(DB_ENDPOINT):3309/day1"}'

# GitHub 토큰 업데이트
aws secretsmanager update-secret \
  --secret-id gj2025-github-token \
  --secret-string '{"token":"$(GITHUB_TOKEN)"}'
```

## 6. EKS Addon 설치 순서
```bash
# 1. VPC CNI
eksctl create addon --cluster gj2025-eks-cluster --name vpc-cni

# 2. CoreDNS  
eksctl create addon --cluster gj2025-eks-cluster --name coredns

# 3. kube-proxy
eksctl create addon --cluster gj2025-eks-cluster --name kube-proxy

# 4. EBS CSI Driver
eksctl create addon --cluster gj2025-eks-cluster --name aws-ebs-csi-driver
```

## 7. Argo Rollouts 설정
```bash
# Rollout 리소스 생성
cat > rollouts.yaml <<EOF
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: red-rollout
  namespace: skills
spec:
  replicas: 2
  strategy:
    blueGreen:
      activeService: red-svc
      previewService: red-svc-preview
      autoPromotionEnabled: false
  selector:
    matchLabels:
      app: red
  template:
    metadata:
      labels:
        app: red
    spec:
      containers:
      - name: red
        image: $(ACCOUNT_ID).dkr.ecr.$(AWS_REGION).amazonaws.com/red:v1.0.0
        ports:
        - containerPort: 8080
        envFrom:
        - secretRef:
            name: db-secret
EOF

kubectl apply -f rollouts.yaml
```

## 8. 채점 기준 충족 확인
```bash
# 모든 리소스 확인
aws ec2 describe-vpcs --filters Name=tag:Name,Values=gj2025-hub-vpc
aws ec2 describe-vpcs --filters Name=tag:Name,Values=gj2025-app-vpc
aws eks describe-cluster --name gj2025-eks-cluster
aws rds describe-db-instances --db-instance-identifier gj2025-db-instance
aws rds describe-db-proxies --db-proxy-name gj2025-rds-proxy
```
