# Skills Competition 2025 - Cloud Computing Infrastructure

## 📋 개요

2025년도 전국기능경기대회 클라우드컴퓨팅 직종 제1과제를 위한 인프라 자동화 솔루션입니다.
MSA 패턴의 REST API를 Kubernetes 환경에서 운영하기 위한 완전 자동화된 인프라를 제공합니다.

## 🏗️ 아키텍처

- **VPC**: Hub VPC (10.0.0.0/16) + App VPC (192.168.0.0/16)
- **Network Firewall**: ifconfig.me 차단 규칙 포함
- **EKS Cluster**: v1.32, Private endpoint, KMS 암호화
- **RDS Aurora MySQL**: 8.0.mysql_aurora.3.08.2, Backtracking 활성화
- **OpenSearch**: v2.19, 마스터 3개, 데이터 노드 2개
- **Load Balancer**: ALB (Internal) + NLB (Internal/External) with PrivateLink
- **Container Registry**: ECR with KMS 암호화, 이미지 스캔
- **Monitoring**: CloudWatch Container Insights
- **Logging**: Fluent Bit → OpenSearch (JSON 파싱, /health 제외)
- **CD**: ArgoCD with S3 Helm Repository

## 📦 필수 파일

다음 파일들이 작업 디렉토리에 있어야 합니다:

```
├── green_1.0.0                # Green 애플리케이션 바이너리 v1.0.0
├── green_1.0.1                # Green 애플리케이션 바이너리 v1.0.1
├── red_1.0.0                  # Red 애플리케이션 바이너리 v1.0.0
├── red_1.0.1                  # Red 애플리케이션 바이너리 v1.0.1
├── day1_table_v1.sql          # 데이터베이스 초기화 스크립트
├── skills-competition.yaml    # CloudFormation 템플릿
├── bastion-setup.sh           # 핵심 자동화 스크립트 (모든 것을 처리)
├── mark.sh                    # 채점 스크립트 (수정 금지)
└── README.md                  # 사용 가이드
```

## 🚀 배포 방법

### 1. 사전 준비

1. **AWS CLI 설정**
   ```bash
   aws configure
   # Access Key, Secret Key, Region (ap-northeast-2) 설정
   ```

2. **GitHub Personal Access Token 생성**
   - GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)
   - repo 권한 필요

3. **EC2 Key Pair 생성** (선택사항)
   ```bash
   aws ec2 create-key-pair --key-name skills-keypair --region ap-northeast-2 --query 'KeyMaterial' --output text > skills-keypair.pem
   chmod 400 skills-keypair.pem
   ```

### 2. CloudFormation 배포 (AWS 콘솔)

1. **AWS 콘솔** → **CloudFormation** → **스택 생성**
2. **skills-competition.yaml** 업로드
3. **파라미터 설정**:
   - BucketSuffix: `arco` (4자리 영문)
   - KeyPairName: `skills-keypair` (생성한 키페어 이름)
4. **스택 배포 완료 대기** (약 10-15분)

### 3. Bastion 설정

#### 3-1. Bastion IP 확인

```bash
# CloudFormation 출력에서 Bastion IP 확인
BASTION_IP=$(aws cloudformation describe-stacks \
    --stack-name skills-competition \
    --query "Stacks[0].Outputs[?OutputKey=='BastionPublicIP'].OutputValue" \
    --output text \
    --region ap-northeast-2)
echo "Bastion IP: $BASTION_IP"
```

#### 3-2. Bastion 접속

```bash
# SSH 접속 (포트 2025)
ssh -p 2025 ec2-user@$BASTION_IP
# 비밀번호: Skill53##

# 또는 Key Pair 사용
ssh -i "skills-keypair.pem" -p 2025 ec2-user@$BASTION_IP
```

#### 3-3. 파일 업로드

```bash
# SSH로 파일 복사
scp -P 2025 green_1.0.0 green_1.0.1 red_1.0.0 red_1.0.1 day1_table_v1.sql ec2-user@$BASTION_IP:~/
scp -P 2025 bastion-setup.sh mark.sh ec2-user@$BASTION_IP:~/
```

#### 3-4. Bastion 설정 실행

**UserData는 SSH 설정만 처리하고, 나머지는 bastion-setup.sh에서 자동화**

```bash
# SSH 접속 후 설정 스크립트 실행
chmod +x bastion-setup.sh
./bastion-setup.sh ghp_xxxxxxxxxxxx

# 이 스크립트가 자동으로 설치:
# - Docker, AWS CLI, kubectl, Helm, eksctl, ArgoCD CLI, GitHub CLI
# - EKS 클러스터 생성 및 설정
# - ArgoCD, Container Insights, Fluent Bit 등 모든 구성
```

## 🧪 채점

bastion-setup.sh 실행 완료 후 채점을 진행합니다.

### 자동 설정 채점 (권장)

```bash
# bastion-setup.sh가 안내하는 대로 실행
sed "s/skills-chart-bucket-<영문 4자리>/skills-chart-bucket-arco/g" mark.sh > mark.sh.temp
chmod +x mark.sh.temp
./mark.sh.temp
```

### 수동 채점

```bash
# 환경변수 로드 후 원본 mark.sh 실행
source ~/.bashrc
./mark.sh
```

**참고**: bastion-setup.sh에서 이미 ArgoCD 포트포워딩과 로그인이 자동으로 설정됩니다!

## 📊 주요 리소스

### VPC 구성
| 이름 | CIDR | 용도 |
|------|------|------|
| skills-hub-vpc | 10.0.0.0/16 | Bastion, Network Firewall |
| skills-app-vpc | 192.168.0.0/16 | Application, Database |

### 서브넷 구성
| 이름 | CIDR | 가용 영역 | 용도 |
|------|------|-----------|------|
| skills-hub-subnet-a | 10.0.0.0/24 | A | Bastion |
| skills-hub-subnet-b | 10.0.1.0/24 | B | Hub |
| skills-inspect-subnet-a | 10.0.2.0/24 | A | Network Firewall |
| skills-inspect-subnet-b | 10.0.3.0/24 | B | Network Firewall |
| skills-app-subnet-a | 192.168.0.0/24 | A | Load Balancer |
| skills-app-subnet-b | 192.168.1.0/24 | B | Load Balancer |
| skills-workload-subnet-a | 192.168.2.0/24 | A | EKS Nodes |
| skills-workload-subnet-b | 192.168.3.0/24 | B | EKS Nodes |
| skills-db-subnet-a | 192.168.4.0/24 | A | RDS |
| skills-db-subnet-b | 192.168.5.0/24 | B | RDS |

### Load Balancer
| 이름 | 타입 | 스킴 | 용도 |
|------|------|------|------|
| skills-alb | ALB | internal | 애플리케이션 로드밸런싱 |
| skills-internal-nlb | NLB | internal | PrivateLink 연결 |
| skills-nlb | NLB | internet-facing | 외부 접근 |

## 🔍 트러블슈팅

### 일반적인 문제

1. **CloudFormation 배포 실패**
   ```bash
   # 스택 상태 확인
   aws cloudformation describe-stack-events --stack-name skills-competition --region ap-northeast-2
   
   # 스택 삭제 후 재배포
   aws cloudformation delete-stack --stack-name skills-competition --region ap-northeast-2
   ```

2. **Bastion 접속 불가**
   ```bash
   # Security Group 확인
   aws ec2 describe-security-groups --group-names skills-bastion-sg --region ap-northeast-2
   
   # 인스턴스 상태 확인
   aws ec2 describe-instances --filters "Name=tag:Name,Values=skills-bastion" --region ap-northeast-2
   ```

3. **EKS 클러스터 문제**
   ```bash
   # 클러스터 상태 확인
   aws eks describe-cluster --name skills-eks-cluster --region ap-northeast-2
   
   # kubeconfig 재설정
   aws eks update-kubeconfig --region ap-northeast-2 --name skills-eks-cluster
   ```

4. **ArgoCD 동기화 문제**
   ```bash
   # ArgoCD 애플리케이션 상태 확인
   argocd app get green
   argocd app get red
   
   # 수동 동기화
   argocd app sync green
   argocd app sync red
   ```

### 채점 관련 문제

1. **환경변수 미설정**
   ```bash
   source config.env
   echo $BUCKET_NAME
   echo $GITHUB_USER
   ```

2. **GitHub 인증 문제**
   ```bash
   gh auth status
   gh auth login --with-token < github_token.txt
   ```

3. **Docker 권한 문제**
   ```bash
   sudo usermod -a -G docker ec2-user
   sudo chmod 666 /var/run/docker.sock
   newgrp docker
   ```

## 📋 채점 체크리스트

- [ ] VPC/Subnet CIDR 설정
- [ ] VPC Endpoint (ECR, S3) 구성
- [ ] VPC Peering 연결
- [ ] Network Firewall ifconfig.me 차단
- [ ] Bastion 서버 설정 (t3.small, SSH 2025)
- [ ] Secret Store (KMS 암호화)
- [ ] RDS Aurora MySQL (8.0.mysql_aurora.3.08.2)
- [ ] S3 Bucket 및 Helm Chart
- [ ] ECR Repository (KMS 암호화, 스캔)
- [ ] EKS Cluster (v1.32, Private endpoint)
- [ ] NodeGroup (App: t3.medium, Addon: t3.medium)
- [ ] Fargate Profile (CoreDNS)
- [ ] Load Balancer (ALB + NLB)
- [ ] OpenSearch (v2.19, 마스터 3개, 데이터 2개)
- [ ] Fluent Bit 로깅 (JSON 파싱, /health 제외)
- [ ] Container Insights 모니터링
- [ ] ArgoCD S3 연동
- [ ] Blue/Green 배포 테스트

## 📞 지원

채점 과정에서 문제가 발생하면 다음을 확인하세요:

1. **로그 확인**: CloudFormation Events, EKS 로그, Pod 로그
2. **네트워크 연결**: Security Group, Route Table, VPC Endpoint
3. **권한 확인**: IAM Role, Service Account
4. **리소스 상태**: 모든 리소스가 Active/Ready 상태인지 확인

모든 설정이 채점 기준에 맞춰 자동화되어 있으니, 스크립트를 순서대로 실행하면 성공적으로 배포됩니다.
