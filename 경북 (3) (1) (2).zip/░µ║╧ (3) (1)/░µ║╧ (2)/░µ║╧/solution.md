# 과제 순서

1. VPC Workload, Network Firewall 생성
2. Bastion 생성
3. Bastion 접속 → Github CLI 다운로드
4. RDS, Opensearch Cluster 생성
5. KMS, Secrets Manager 생성
6. S3 준비
7. ECR 생성, v1.0.0 Application Push
8. 데이터베이스 준비
9. EKS Cluster, Node 생성
10. 쿠버네티스 과정 진행

VPC

VPC Endpoints

- ecr.dkr
- s3

## 🌐 VPC Routing

| 우선순위 | 규칙 |
| --- | --- |
| 1 | [ifconfig.me](http://ifconfig.me) HTTP/HTTPS Block |

## VPC Routing

### skills-hub-igw-rtb

| 대상 | 대상 |
| --- | --- |
| 10.0.0.0/24 | Network Firewall A |
| 10.0.1.0/24 | Network Firewall B |

### skills-hub-a-rtb

| 대상 | 대상 |
| --- | --- |
| 0.0.0.0/0 | Network Firewall A |
| 192.168.0.0/16 | VPC Peering |

### skills-hub-b-rtb

| 대상 | 대상 |
| --- | --- |
| 0.0.0.0/0 | Network Firewall B |
| 192.168.0.0/16 | VPC Peering |

### skills-inspect-a-rtb, skills-inspect-b-rtb

| 대상 | 대상 |
| --- | --- |
| 0.0.0.0/0 | Internet Gateway |

### skills-app-rtb

| 대상 | 대상 |
| --- | --- |
| 0.0.0.0/0 | Internet Gateway |

### skills-workload-a-rtb, skills-workload-b-rtb

| 대상 | 대상 |
| --- | --- |
| pl-xxxxxx | S3 VPC Endpoint |
| 0.0.0.0/0 | NAT Gateway |
| 10.0.0.0/16 | VPC Peering |

### skills-db-rtb

| 대상 | 대상 |
| --- | --- |
| 10.0.0.0/16 | VPC Peering |

## 🐳 Dockerfile

### ✅ green

```
FROM public.ecr.aws/docker/library/alpine:3.21.3

WORKDIR /app

COPY green_1.0.0 .

RUN apk --no-cache add curl
RUN chmod +x ./green_1.0.0

CMD ["./green_1.0.0"]
```

### ✅ red

```
FROM public.ecr.aws/docker/library/alpine:3.21.3

WORKDIR /app

COPY red_1.0.0 .

RUN apk --no-cache add curl
RUN chmod +x ./red_1.0.0

CMD ["./red_1.0.0"]
```

---

## 🗄️ 데이터베이스

```sql
CREATE DATABASE IF NOT EXISTS day1;
USE day1;

CREATE TABLE IF NOT EXISTS green (
    uuid VARCHAR(8) PRIMARY KEY,
    x VARCHAR(255) NOT NULL,
    y DOUBLE NOT NULL
);

CREATE TABLE IF NOT EXISTS red (
    uuid VARCHAR(8) PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);
```

---

## ☸️ 쿠버네티스

- Fargate로 **coredns** 배포 (namespace: `kube-system`, label: `k8s-app=kube-dns`)
- `skills` namespace 생성
- 환경변수 설정
- Addon 설치:
    - Container Insights
    - AWS Load Balancer Controller
    - External Secrets Operator
    - Fluent-Bit
    - ArgoCD & Argo Rollouts

---

## 🛠️ ArgoCD

### IAM ServiceAccount 생성

```bash
eksctl create iamserviceaccount \
  --cluster=$CLUSTER_NAME \
  --namespace=argocd \
  --name=argocd-repo-server \
  --role-name ArgocdRepoServerRole \
  --attach-policy-arn=arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess \
  --approve
```

### values.yaml

```yaml
repoServer:
  serviceAccount:
    create: false
    name: argocd-repo-server

  initContainers:
    - name: download-tools
      image: alpine:latest
      command: [sh, -ec]
      env:
        - name: HELM_S3_VERSION
          value: "0.15.1"
      args:
        - |
          rm -rf /custom-tools/*
          mkdir -p /custom-tools/helm-plugins
          mkdir -p /custom-tools/helm-plugins/helm-s3
          wget https://github.com/hypnoglow/helm-s3/releases/download/v${HELM_S3_VERSION}/helm-s3_${HELM_S3_VERSION}_linux_amd64.tar.gz -qO- | tar -C /custom-tools/helm-plugins/helm-s3 -xz;

      volumeMounts:
        - mountPath: /custom-tools
          name: custom-tools

  env:
    - name: HELM_PLUGINS
      value: /custom-tools/helm-plugins/

  volumes:
    - name: custom-tools
      emptyDir: {}

configs:
  cm:
    timeout.reconciliation: 30s
  params:
    server.insecure: true

```

---

## 📦 Helm

```bash
helm create app
helm package .
helm repo index .
```

---

### templates/deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.appName }}-deploy
  namespace: {{ .Release.Namespace }}
spec:
  replicas: 2
  selector:
    matchLabels:
      app: {{ .Values.appName }}
  template:
    metadata:
      labels:
        app: {{ .Values.appName }}
    spec:
      terminationGracePeriodSeconds: 60
      nodeSelector:
        skills: app
      tolerations:
      - key: skills
        operator: Equal
        value: app
        effect: NoSchedule
      containers:
      - name: {{ .Values.appName }}
        image: <ECR_REPO>/skills-{{ .Values.appName }}-repo:{{ .Values.tag }}
        imagePullPolicy: Always
        envFrom:
        - secretRef:
            name: db-secret
        ports:
        - containerPort: 8080
```

---

### templates/service.yaml

```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ .Values.appName }}-svc
  namespace: {{ .Release.Namespace }}
spec:
  type: NodePort
  selector:
    app: {{ .Values.appName }}
  ports:
    - protocol: TCP
      port: 80
      targetPort: 8080
```

---

### templates/ingress.yaml

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ .Values.appName }}-ing
  namespace: {{ .Release.Namespace }}
  annotations:
    alb.ingress.kubernetes.io/load-balancer-name: skills-alb
    alb.ingress.kubernetes.io/target-type: instance
    alb.ingress.kubernetes.io/group.name: app
    alb.ingress.kubernetes.io/target-node-labels: skills=app
    alb.ingress.kubernetes.io/scheme: internal
    alb.ingress.kubernetes.io/healthcheck-path: /health
spec:
  ingressClassName: alb
  rules:
    - http:
        paths:
          - path: /{{ .Values.appName }}
            pathType: Exact
            backend:
              service:
                name: {{ .Values.appName }}-svc
                port:
                  number: 80
          - path: /health
            pathType: Exact
            backend:
              service:
                name: {{ .Values.appName }}-svc
                port:
                  number: 80
```

---

### values.yaml

```yaml
#green.values.yaml
appName: green
tag: v1.0.0

#red.values.yaml
appName: red
tag: v1.0.0
```

---

### ArgoCD Application

### green.yaml / red.yaml

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: green
  namespace: argocd
spec:
  project: default
  sources:
  - repoURL: s3://skills-chart-bucket-arco/app/
    chart: app
    targetRevision: 1.0.0
    helm:
      valueFiles:
      - $values/green.values.yaml
  - repoURL: https://github.com/github_user/day1-values.git
    targetRevision: HEAD
    ref: values
  destination:
    server: https://kubernetes.default.svc
    namespace: skills
```

---

## 🔥 Fluent Bit

- `DaemonSet.yaml` 다운로드 후 toleration 추가
- example log:
    
    `2025/07/11 15:41:23 [2025-07-11T15:41:23Z] GET /health from 192.168.2.91:58920`
    

### configmap.yaml

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: fluent-bit-config
  namespace: amazon-cloudwatch
  labels:
    k8s-app: fluent-bit
data:
  fluent-bit.conf: |
    [SERVICE]
        Flush                     5
        Grace                     30
        Log_Level                 error
        Daemon                    off
        Parsers_File              parsers.conf
        HTTP_Server               ${HTTP_SERVER}
        HTTP_Listen               0.0.0.0
        HTTP_Port                 ${HTTP_PORT}
        storage.path              /var/fluent-bit/state/flb-storage/
        storage.sync              normal
        storage.checksum          off
        storage.backlog.mem_limit 5M

    [INPUT]
        Name                tail
        Tag                 application.*
        Path                /var/log/containers/green*.log,/var/log/containers/red*.log
        multiline.parser    docker, cri
        DB                  /var/fluent-bit/state/flb_container.db
        Mem_Buf_Limit       50MB
        Skip_Long_Lines     On
        Refresh_Interval    10
        Rotate_Wait         30
        storage.type        filesystem
        Read_from_Head      ${READ_FROM_HEAD}

    [FILTER]
        Name    grep
        Match   *
        Exclude log /health

    [FILTER]
        Name     parser
        Match    *
        Key_name log
        Parser   app

    [OUTPUT]
        Name               es
        Match              *
        Host               <opensearch-endpoint>
        Port               443
        Index              app-log
        AWS_Auth           On
        AWS_Region         ap-northeast-2
        tls                On
        Time_Key           timestamp
        Suppress_Type_Name On

  parsers.conf: |
    [PARSER]
        Name   app
        Format regex
        Regex  ^(?<date>[^ ]*) (?<time>[^ ]*) \[(?<timestamp>[^\]]*)\] (?<method>[^ ]*)
```