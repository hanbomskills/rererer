#!/bin/bash
set -euo pipefail

# 현재 TaskDefinition에서 Role ARN 추출
CURRENT_TD=$(aws ecs describe-task-definition --task-definition ws25-ecs-green-taskdef --query 'taskDefinition' --output json 2>/dev/null)
TASK_ROLE_ARN=$(echo "$CURRENT_TD" | jq -r '.taskRoleArn')
EXECUTION_ROLE_ARN=$(echo "$CURRENT_TD" | jq -r '.executionRoleArn')

# StudentNumber 자동 감지
STUDENT_NUMBER=$(aws s3 ls | grep "ws25-cd-green-artifact-" | awk '{print $3}' | sed 's/ws25-cd-green-artifact-//' | head -1)
if [ -z "$STUDENT_NUMBER" ]; then
    exit 1
fi
GREEN_BUCKET="ws25-cd-green-artifact-${STUDENT_NUMBER}"

# v1.0.1 이미지로 새 TaskDefinition 생성
NEW_TD_ARN=$(aws ecs register-task-definition \
  --family ws25-ecs-green-taskdef \
  --task-role-arn "$TASK_ROLE_ARN" \
  --execution-role-arn "$EXECUTION_ROLE_ARN" \
  --network-mode awsvpc \
  --requires-compatibilities EC2 \
  --cpu 1024 \
  --memory 1024 \
  --container-definitions '[
    {
      "name": "log-router",
      "image": "public.ecr.aws/aws-observability/aws-for-fluent-bit:stable",
      "essential": true,
      "user": "0",
      "firelensConfiguration": {
        "type": "fluentbit",
        "options": {
          "enable-ecs-log-metadata": "true"
        }
      },
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "firelens",
          "awslogs-create-group": "true",
          "awslogs-region": "ap-northeast-2",
          "awslogs-stream-prefix": "ecs"
        }
      }
    },
    {
      "name": "green",
      "image": "'$(aws sts get-caller-identity --query Account --output text)'.dkr.ecr.ap-northeast-2.amazonaws.com/green:v1.0.1",
      "portMappings": [{"containerPort": 8080, "hostPort": 8080, "protocol": "tcp"}],
      "essential": true,
      "logConfiguration": {
        "logDriver": "awsfirelens",
        "options": {
          "log_group_name": "/ws25/logs/green",
          "log_stream_name": "Green-$(ecs_task_id)",
          "region": "ap-northeast-2",
          "exclude-patterns": "health",
          "auto_create_group": "true",
          "Name": "cloudwatch"
        }
      },
      "secrets": [
        {"name": "DB_USER", "valueFrom": "'$(aws secretsmanager describe-secret --secret-id ws25/secret/key --query 'ARN' --output text)':DB_USER::"},
        {"name": "DB_PASSWD", "valueFrom": "'$(aws secretsmanager describe-secret --secret-id ws25/secret/key --query 'ARN' --output text)':DB_PASSWD::"},
        {"name": "DB_URL", "valueFrom": "'$(aws secretsmanager describe-secret --secret-id ws25/secret/key --query 'ARN' --output text)':DB_URL::"}
      ],
      "healthCheck": {
        "command": ["CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"],
        "interval": 30,
        "timeout": 5,
        "retries": 5,
        "startPeriod": 10
      }
    }
  ]' \
  --query 'taskDefinition.taskDefinitionArn' --output text 2>/dev/null)

# CodeDeploy용 artifact 생성 (새 TaskDefinition 사용) - 배포 전에 먼저!
cat /home/ec2-user/pipeline/artifact/green/appspec.yml | jq --arg td "$NEW_TD_ARN" '.Resources[0].TargetService.Properties.TaskDefinition = $td' > /tmp/green-appspec-updated.yml 2>/dev/null
mv /tmp/green-appspec-updated.yml /home/ec2-user/pipeline/artifact/green/appspec.yml

cd /home/ec2-user/pipeline/artifact/green
zip -r ../artifact.zip . >/dev/null 2>&1
aws s3 cp ../artifact.zip s3://$GREEN_BUCKET/artifact.zip >/dev/null 2>&1

aws codepipeline start-pipeline-execution --name ws25-cd-green-pipeline >/dev/null 2>&1